export interface Todo{
    id:string;
    title:string;
    isComplete:boolean;
    date:Date;
}