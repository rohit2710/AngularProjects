//package com.grievance.dto;
//
//import javax.persistence.Column;
//
//public class CitizenRegistrationDTO {
//
//	private String name;
//	private String email;
//	private String password;
//	private String mobileNo;
//	private String aadharNo;
//	private String houseNo;
//	private String landmark;
//	private String pincode;
//	
//	public CitizenRegistrationDTO() {
//		super();
//	}
//
//	public CitizenRegistrationDTO(String name, String email, String password, String mobileNo, String aadharNo,
//			String houseNo, String landmark, String pincode) {
//		super();
//		this.name = name;
//		this.email = email;
//		this.password = password;
//		this.mobileNo = mobileNo;
//		this.aadharNo = aadharNo;
//		this.houseNo = houseNo;
//		this.landmark = landmark;
//		this.pincode = pincode;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	public String getMobileNo() {
//		return mobileNo;
//	}
//
//	public void setMobileNo(String mobileNo) {
//		this.mobileNo = mobileNo;
//	}
//
//	public String getAadharNo() {
//		return aadharNo;
//	}
//
//	public void setAadharNo(String aadharNo) {
//		this.aadharNo = aadharNo;
//	}
//
//	public String getHouseNo() {
//		return houseNo;
//	}
//
//	public void setHouseNo(String houseNo) {
//		this.houseNo = houseNo;
//	}
//
//	public String getLandmark() {
//		return landmark;
//	}
//
//	public void setLandmark(String landmark) {
//		this.landmark = landmark;
//	}
//
//	public String getPincode() {
//		return pincode;
//	}
//
//	public void setPincode(String pincode) {
//		this.pincode = pincode;
//	}
//
//	@Override
//	public String toString() {
//		return "CitizenRegistrationDTO [name=" + name + ", email=" + email + ", password=" + password + ", mobileNo="
//				+ mobileNo + ", aadharNo=" + aadharNo + ", houseNo=" + houseNo + ", landmark=" + landmark + ", pincode="
//				+ pincode + "]";
//	}
//	
//}
