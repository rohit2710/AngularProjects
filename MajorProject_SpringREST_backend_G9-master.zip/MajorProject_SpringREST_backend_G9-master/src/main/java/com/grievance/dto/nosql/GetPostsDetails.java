package com.grievance.dto.nosql;

import java.util.List;

import com.grievance.nosql.entity.PostComment;
import com.grievance.nosql.entity.Rating;

public class GetPostsDetails {
	private List<Integer> likes;
	private List<Integer> dislikes;
	private List<PostComment> postComments;
	private List<Rating> ratings;
	public GetPostsDetails() {
		super();
	}

	public GetPostsDetails(List<Integer> likes, List<Integer> dislikes, List<PostComment> postComments,
			List<Rating> ratings) {
		super();
		this.likes = likes;
		this.dislikes = dislikes;
		this.postComments = postComments;
		this.ratings = ratings;
	}

	public List<Integer> getLikes() {
		return likes;
	}

	public void setLikes(List<Integer> likes) {
		this.likes = likes;
	}

	public List<Integer> getDislikes() {
		return dislikes;
	}

	public void setDislikes(List<Integer> dislikes) {
		this.dislikes = dislikes;
	}

	public List<PostComment> getPostComments() {
		return postComments;
	}

	public void setPostComments(List<PostComment> postComments) {
		this.postComments = postComments;
	}


	public List<Rating> getRatings() {
		return ratings;
	}

	public void setRatings(List<Rating> ratings) {
		this.ratings = ratings;
	}

	@Override
	public String toString() {
		return "GetPosts [likes=" + likes + ", dislikes=" + dislikes + ", postComments=" + postComments + "]";
	}
}
