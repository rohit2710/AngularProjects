package com.grievance.dto;

//DTO
public class EmployeeDTO {

	private Integer employeeId;
	private String name;
	private String email;
	private String role;
	private String mobileNo;
	private String departmentName;
	
	public EmployeeDTO() {
		super();
	}

	public EmployeeDTO(Integer employeeId, String name, String email, String role, String mobileNo,
			String departmentName) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.email = email;
		this.role = role;
		this.mobileNo = mobileNo;
		this.departmentName = departmentName;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	@Override
	public String toString() {
		return "EmployeeDTO [employeeId=" + employeeId + ", name=" + name + ", email=" + email + ", role=" + role
				+ ", mobileNo=" + mobileNo + ", departmentName=" + departmentName + "]";
	}
	
}
