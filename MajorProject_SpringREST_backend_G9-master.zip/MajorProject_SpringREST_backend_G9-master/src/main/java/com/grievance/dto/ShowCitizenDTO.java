package com.grievance.dto;

public class ShowCitizenDTO {
	private String name;
	private String email;
	private String mobileNo;
	private String aadharNo;

	public ShowCitizenDTO() {
		super();
	}

	public ShowCitizenDTO(String name, String email, String mobileNo, String aadharNo) {
		super();
		this.name = name;
		this.email = email;
		this.mobileNo = mobileNo;
		this.aadharNo = aadharNo;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	@Override
	public String toString() {
		return "ShowCitizenDTO [name=" + name + ", email=" + email + ", mobileNo=" + mobileNo + ", aadharNo=" + aadharNo
				+ "]";
	}


}
