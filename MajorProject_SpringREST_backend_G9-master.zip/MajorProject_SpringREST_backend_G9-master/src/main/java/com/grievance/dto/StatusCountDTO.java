package com.grievance.dto;

public class StatusCountDTO {
	private String Status;
	private long count;
	public StatusCountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StatusCountDTO(String status, long count) {
		super();
		Status = status;
		this.count = count;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "StatusCountDTO [Status=" + Status + ", count=" + count + "]";
	}
	
	
}
