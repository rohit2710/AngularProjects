package com.grievance.dto;

//DTO
public class ComplaintAddress {

	private int addressId;
	private String houseNo;
	private String landmark;
	private String pincode;

	public ComplaintAddress() {
		super();
	}

	public ComplaintAddress(int addressId, String houseNo, String landmark, String pincode) {
		super();
		this.addressId = addressId;
		this.houseNo = houseNo;
		this.landmark = landmark;
		this.pincode = pincode;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "ComplaintAddress [addressId=" + addressId + ", houseNo=" + houseNo + ", landmark=" + landmark
				+ ", pincode=" + pincode + "]";
	}


}
