package com.grievance.dto.nosql;

public class PostCounts {
	private Integer totalLikes;
	private Integer totalDislike;
	private Integer totalComments;
	private Integer averageRating;
	private Integer totalRating;

	public PostCounts() {
	}

	public PostCounts(Integer totalLikes, Integer totalDislike, Integer totalComments, Integer averageRating,
			Integer totalRating) {
		super();
		this.totalLikes = totalLikes;
		this.totalDislike = totalDislike;
		this.totalComments = totalComments;
		this.averageRating = averageRating;
		this.totalRating = totalRating;
	}

	public PostCounts(Integer totalLikes, Integer totalDislike) {
		super();
		this.totalLikes = totalLikes;
		this.totalDislike = totalDislike;
	}

	public Integer getTotalLikes() {
		return totalLikes;
	}

	public void setTotalLikes(Integer totalLikes) {
		this.totalLikes = totalLikes;
	}

	public Integer getTotalDislike() {
		return totalDislike;
	}

	public void setTotalDislike(Integer totalDislike) {
		this.totalDislike = totalDislike;
	}

	public Integer getTotalComments() {
		return totalComments;
	}

	public Integer getAverageRating() {
		return averageRating;
	}

	public Integer getTotalRating() {
		return totalRating;
	}

	public void setTotalComments(Integer totalComments) {
		this.totalComments = totalComments;
	}

	public void setAverageRating(Integer averageRating) {
		this.averageRating = averageRating;
	}

	public void setTotalRating(Integer totalRating) {
		this.totalRating = totalRating;
	}

}
