package com.grievance.dto;

public class ComplaintRegisterDTO {
	
	private String complaintMessage;
	private String documentPath;
	private Integer departmentId;
	private Integer addressId;

	public ComplaintRegisterDTO() {
		super();
	}

	public ComplaintRegisterDTO(String complaintMessage, String documentPath, Integer departmentId, Integer addressId) {
		super();
		this.complaintMessage = complaintMessage;
		this.documentPath = documentPath;
		this.departmentId = departmentId;
		this.addressId = addressId;
	}

	public String getComplaintMessage() {
		return complaintMessage;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setComplaintMessage(String complaintMessage) {
		this.complaintMessage = complaintMessage;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	@Override
	public String toString() {
		return "ComplaintRegisterDTO [complaintMessage=" + complaintMessage + ", documentPath=" + documentPath
				+ ", departmentId=" + departmentId + ", addressId=" + addressId + "]";
	}

}
