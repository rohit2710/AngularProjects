package com.grievance.entity;

import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Complaint {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "complaintid")
	private Integer complaintId;
	@Column(name = "complaintmessage")
	private String complaintMessage;
	@CreationTimestamp
	@Column(name = "createdat")
	private Instant createdAt;
	@Column(name = "updatedat")
	private Instant updatedAt;
	@Column(name = "resolvedat")
	private Instant resolvedAt;
	@Column(name = "complaintstatus")
	private String complaintStatus;
	@Column(name = "documentpath")
	private String documentPath;
	private boolean reminder;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "citizenid", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JsonIgnore
	private Citizen citizen;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "departmentid", nullable = true)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JsonIgnore
	private Department department;


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "addressid", nullable = false)
	@OnDelete(action = OnDeleteAction.NO_ACTION)
	@JsonIgnore
	private Address address;

	private String feedbackPostId;
	private String chatId;

	public Complaint() {
		super();
	}

	public Complaint(String complaintMessage, String documentPath) {
		super();
		this.complaintMessage = complaintMessage;
		this.documentPath = documentPath;
	}

	public Integer getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintMessage() {
		return complaintMessage;
	}

	public void setComplaintMessage(String complaintMessage) {
		this.complaintMessage = complaintMessage;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Instant getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Instant getResolvedAt() {
		return resolvedAt;
	}


	public Address getAddress() {
		return address;
	}

	public void setResolvedAt(Instant resolvedAt) {
		this.resolvedAt = resolvedAt;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public boolean isReminder() {
		return reminder;
	}

	public void setReminder(boolean reminder) {
		this.reminder = reminder;
	}

	public Citizen getCitizen() {
		return citizen;
	}

	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getFeedbackPostId() {
		return feedbackPostId;
	}

	public void setFeedbackPostId(String feedbackPostId) {
		this.feedbackPostId = feedbackPostId;
	}

	public String getChatId() {
		return chatId;
	}

	public void setChatId(String chatId) {
		this.chatId = chatId;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Complaint [complaintId=" + complaintId + ", complaintMessage=" + complaintMessage + ", createdAt="
				+ createdAt + ", updatedAt=" + updatedAt + ", resolvedAt=" + resolvedAt + ", complaintStatus="
				+ complaintStatus + ", documentPath=" + documentPath + ", reminder=" + reminder + ", feedbackPostId="
				+ feedbackPostId + ", chatId=" + chatId + "]";
	}

}