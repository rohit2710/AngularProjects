package com.grievance.entity;

public enum ComplaintStatus {
	PENDING,
	RESOLVED,
	REOPENED;


}
