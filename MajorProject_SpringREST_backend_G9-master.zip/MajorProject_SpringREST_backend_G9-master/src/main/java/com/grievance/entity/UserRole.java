package com.grievance.entity;

public enum UserRole {
	ADMIN,
	DEPARTMENTHEAD,
	CITIZEN
}
