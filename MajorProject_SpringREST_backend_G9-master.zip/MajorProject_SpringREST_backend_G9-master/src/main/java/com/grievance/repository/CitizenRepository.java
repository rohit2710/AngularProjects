package com.grievance.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grievance.entity.Citizen;

@Repository
public interface CitizenRepository extends JpaRepository<Citizen, Integer>{

	public Citizen findByEmail(String email);
	public Optional<Citizen> findByCitizenId(Integer citizenId);
	
	@Query("SELECT c FROM  Citizen c WHERE c.isActived = 0 AND c.loginAttempts = 3")
	public List<Citizen> getAllDeactiveCitizen();

}
