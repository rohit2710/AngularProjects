package com.grievance.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grievance.entity.Auth;
import com.grievance.entity.Citizen;
import com.grievance.entity.Employee;

@Repository
public interface AuthRepository extends JpaRepository<Auth, Integer>{

	public Optional<Auth> findByCitizenAndOtp(Citizen citizen,Integer otp);

	public Auth findByEmployee(Employee employee);
	
	public Auth deleteByCitizen(Citizen citizen);
   
}
