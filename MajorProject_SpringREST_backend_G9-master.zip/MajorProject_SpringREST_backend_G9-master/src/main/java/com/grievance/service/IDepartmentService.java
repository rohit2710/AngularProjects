package com.grievance.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.grievance.dto.UpdateRemark;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.entity.Employee;
import com.grievance.nosql.entity.Chat;

public interface IDepartmentService {
	public Employee getDepartmentById(int employeeId);
	public List<Complaint> getComplaintsOfDepartmentById(int departmentId,Pageable pageable);
	public Complaint updateStatus(int complaintid, String status);
	public Complaint transferComplaint(int complaintId, int newDepartmentId);
	public Chat updateDepartmentHeadRemark(UpdateRemark updateRemark);
	public Boolean resetPassword(int employeeId, String password);
	public Boolean incrementFailedAttempts(String email);
	public Boolean resetAttempts(String email);
	public Long countByComplaintStatus(String complaintStatus);
	public List<Complaint> getComplaintsByDepartmentAndStatus(String complaintStatus, int departmentId,Pageable pageable);

}
