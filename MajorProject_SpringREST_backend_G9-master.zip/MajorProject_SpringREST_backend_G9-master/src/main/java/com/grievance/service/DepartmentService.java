package com.grievance.service;

import java.time.Instant;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.grievance.dto.UpdateRemark;
import com.grievance.entity.Complaint;
import com.grievance.entity.Department;
import com.grievance.entity.Employee;
import com.grievance.exception.ComplaintException;
import com.grievance.exception.DepartmentException;
import com.grievance.exception.EmployeeException;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.entity.Messages;
import com.grievance.nosql.repository.ChatRepository;
import com.grievance.repository.ComplaintRepository;
import com.grievance.repository.DepartmentRepository;
import com.grievance.repository.EmployeeRepository;

@Service
public class DepartmentService implements IDepartmentService {

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	private ComplaintRepository complaintRepository;

	@Autowired
	private DepartmentRepository departmentRepository;

	@Autowired
	private ChatRepository chatRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	// it will return list of complaints of particular department
	public List<Complaint> getComplaintsOfDepartmentById(int departmentId,Pageable pageable) {
		Department department = departmentRepository.findByDepartmentId(departmentId);
		List<Complaint> complaints = complaintRepository.findByDepartment(department,pageable);
		return complaints;
	}

	public List<Complaint> getComplaintsByDepartmentAndStatus(String complaintStatus, int departmentId,Pageable pageable) {
		Department department = departmentRepository.findByDepartmentId(departmentId);
		List<Complaint> complaints = complaintRepository.findByComplaintStatusAndDepartment(complaintStatus, department, pageable);
		return complaints;
	}

	// it will return employee data using employee id
	public Employee getDepartmentById(int employeeId) {
		return employeeRepository.findById(employeeId).orElse(new Employee());
	}

	//it will update complaint status
	public Complaint updateStatus(int complaintid, String status) {
		Complaint complaints=complaintRepository.findById(complaintid)
				.orElseThrow(() ->
				new DepartmentException("Department Not Found", HttpStatus.NOT_FOUND));
		complaints.setComplaintStatus(status);
		complaints.setUpdatedAt(Instant.now());
		complaintRepository.save(complaints);
		return complaints;
	}

	//it will transfer Complaint to a particular department
	public Complaint transferComplaint(int complaintid, int newDepartmentId) {
		Complaint complaint = complaintRepository.findById(complaintid).orElseThrow();
		Department department = departmentRepository.findById(newDepartmentId).orElseThrow();
		complaint.setDepartment(department);
		this.complaintRepository.save(complaint);
		return complaint;
	}

	//function will update citizen rmark and store it in mongoDB
	@Override
	public Chat updateDepartmentHeadRemark(UpdateRemark updateRemark) {
		Complaint complaint = complaintRepository.findById(updateRemark.getComplaintId())
				.orElseThrow(() -> new ComplaintException("complaionr does not exist", HttpStatus.NOT_FOUND));
		Chat chat = chatRepository.findById(complaint.getChatId()).orElseThrow(); // TODO: //Exception to be added
		Department department = complaint.getDepartment();
		Employee employee = employeeRepository.findByDepartment(department).orElseThrow(
				() -> new EmployeeException("NO employee is assigned to this department", HttpStatus.NOT_FOUND));
		List<Messages> messages = chat.getMessages();
		//		chat.setCitizenId(citizen.getCitizenId());
		Messages message = new Messages();
		message.setMessage(updateRemark.getMessage());
		//		message.setDocumentPath(complaint.getDocumentPath());
		message.setSenderId(employee.getEmployeeId());
		message.setSenderName(employee.getName());
		message.setSenderRole(employee.getRole());
		messages.add(message);
		chat.setMessages(messages);
		return chatRepository.save(chat);
	}

	//reset password
	@Override
	public Boolean resetPassword(int employeeId, String password) {
		Employee employee = this.employeeRepository.findById(employeeId).orElse(null);
		if(employee != null) {
			employee.setPassword(this.bCryptPasswordEncoder.encode(password));
			employeeRepository.save(employee);
			return true;

		}else {
			return false;
		}
	}


	//this will increase count for failed login attempts
	@Override
	public Boolean incrementFailedAttempts(String email) {
		Employee employee = this.employeeRepository.findByEmail(email);
		if(employee == null) {
			return false;
		}else {
			if(employee.getLoginAttempts() <= 2) {
				employee.setLoginAttempts(employee.getLoginAttempts()+1);
			}
			else {
				employee.setActived(false);
			}
			this.employeeRepository.save(employee);
			return true;
		}
	}



	@Override
	public Boolean resetAttempts(String email) {
		Employee employee = this.employeeRepository.findByEmail(email);
		if(employee == null) {
			return false;
		}else {
			employee.setLoginAttempts(0);
			employee.setLastLogin(Instant.now());
			this.employeeRepository.save(employee);
			return true;
		}      
	}


	@Override
	public Long countByComplaintStatus(String complaintStatus) {
		long complaintCount =this.complaintRepository.countByComplaintStatus(complaintStatus);
		return complaintCount;
	}
}
