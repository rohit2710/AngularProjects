package com.grievance.service;

import java.util.List;
import javax.mail.MessagingException;
import com.grievance.entity.Citizen;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.grievance.entity.Complaint;
import com.grievance.entity.Department;
import com.grievance.entity.Employee;

public interface IAdminService {

	public Employee registerEmployee(Employee employee, int departmentId) throws MessagingException;
	public Department registerDepartment(Department department);
	public List<Department> getAllDepartments();
	public Boolean deleteDepartment(int departmentId);
	public Department updateDepartment(Department department, int departmentId);
	public Boolean updateEmployee(Employee employee, int employeeId, int departmentId);
	public Department getDepartment(int departmentId);
	public List<Employee> getAllEmployee();
	public Employee getEmployeeById(int employeeId);
	public Page<Complaint> getAllComplaints(Pageable pageable);
	public List<Complaint> getAllComplaintWithNoDepartment();

	public Long getComplaintCount(String complaintStatus);
	public Long getComplaintCountByDeptAndStatus(String departmentName,String complaintStatus);
	public List<Citizen> getAllDeactiveCitizen();
	public List<Employee> getAllDeactiveEmloyee();
	public Boolean ActiveAccount(String email);
	public List<Complaint> getComplaintByDepartmentName(String departmentName);

}
