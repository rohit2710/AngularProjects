package com.grievance.service;

import java.util.List;

import javax.mail.MessagingException;

import com.grievance.dto.UpdateRemark;
import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.entity.PostFeedback;

public interface ICitizenService {
	public Complaint registerComplaint(Complaint complaint, int citizenId, int departmentId, int addressId) throws MessagingException;
	public List<Complaint> getAllComplaintsOfCitizen(int citizenId);
	public Address getAddressByCitizenId(int addressId);
	public Citizen getUserById(int citizenId);
	public Complaint sendReminder(int complaintId);
	public List<Complaint> getAllComplaints();
	public List<Citizen> getAllCitizens();
	public Boolean resetPassword(int citizenId, String password);
	public Chat createChat(int citizenId, int employeeId);
	public PostFeedback createPostFeedBack();
	public Chat updateCitizenRemark(UpdateRemark updateRemark);
	public List<Address> getAllCitizenAddress(int citizenId);
	public Boolean incrementFailedAttempts(String email);
	public Boolean resetAttempts(String email);

}
