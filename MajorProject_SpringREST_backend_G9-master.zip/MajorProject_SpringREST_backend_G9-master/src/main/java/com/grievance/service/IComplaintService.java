package com.grievance.service;

import com.grievance.dto.GraphDataDTO;

public interface IComplaintService {

	public Long getTotalComplaintsCount();

	public Long getComplaintCountByStatus(String complaintStatus);

	public Long getCountByDepartmentAndStatus(Integer departmentId,String complaintStatus);

	public GraphDataDTO getAllData();

	public GraphDataDTO getDataByDepartment(Integer departmentId);

	public GraphDataDTO getDataByEmployeeId(Integer employeeId);
}
