package com.grievance.service;

import javax.mail.MessagingException;

import com.grievance.entity.Auth;
import com.grievance.entity.Citizen;

public interface IEmailService {

	public String sendEmail(String to, String subject, String text) throws MessagingException;
	public Auth addOTP(int citizenId) throws MessagingException;
	public int generateOtp();
	public Boolean sendOtpForAccountActivation(Citizen citizen) throws MessagingException;
}
