package com.grievance.service;

import com.grievance.dto.UpdatePassword;
import com.grievance.dto.ValidateOtpDTO;
import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Employee;

public interface IAuthenticationService {

	public Citizen registerCitizen(Citizen citizen, Address address);
	public void registerAddress(Citizen citizen, Address address);
	public Citizen validateEmail(String email);
	public Boolean validateOtp(ValidateOtpDTO validateOtpDTO);
	public Boolean updatePassword(UpdatePassword updatePassword);
	public Employee getEmployeeByEmail(String email);
	public Citizen getCitizenByEmail(String email);
	public Employee validateEmployeeEmail(String email);
	public Boolean activateAccount(ValidateOtpDTO validateOtpDTO);
}
