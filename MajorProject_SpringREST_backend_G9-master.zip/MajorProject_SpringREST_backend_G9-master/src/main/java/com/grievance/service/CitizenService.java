package com.grievance.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.grievance.dto.UpdateRemark;
import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.entity.ComplaintStatus;
import com.grievance.entity.Department;
import com.grievance.entity.Employee;
import com.grievance.exception.AdminException;
import com.grievance.exception.CitizenException;
import com.grievance.exception.ComplaintException;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.entity.Messages;
import com.grievance.nosql.entity.PostFeedback;
import com.grievance.nosql.repository.ChatRepository;
import com.grievance.nosql.repository.PostFeedbackRepository;
import com.grievance.repository.AddressRepository;
import com.grievance.repository.AuthRepository;
import com.grievance.repository.CitizenRepository;
import com.grievance.repository.ComplaintRepository;
import com.grievance.repository.DepartmentRepository;
import com.grievance.repository.EmployeeRepository;

@Service
public class CitizenService implements ICitizenService {

	@Autowired
	private CitizenRepository citizenRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private DepartmentRepository departmentRepository;

	@Autowired
	private ComplaintRepository complaintRepository;

	@Autowired
	private ChatRepository chatRepository;

	@Autowired
	PostFeedbackRepository feedbackRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private IEmailService iEmailService;

	// get citizenById
	public Citizen getUserById(int citizenId) {
		return citizenRepository.findById(citizenId).orElseThrow(() -> new CitizenException("Citizen not found", HttpStatus.NOT_FOUND));
	}

	// Complaint Registration
	@Override
	public Complaint registerComplaint(Complaint complaint, int citizenId, int departmentId, int addressId) throws MessagingException {
		Citizen citizen = this.getUserById(citizenId);
		Department department = departmentRepository.findById(departmentId).orElse(new Department());
		Address address = this.getAddressByCitizenId(addressId);
		Optional<Employee> employee = employeeRepository.findByDepartment(department);
		//mail functionality after complaint registration for department head
		if(employee.isPresent()) {
			String to=employee.get().getEmail();
			String subject="New complaint for "+department.getDepartmentName();
			String text="You have a new complaint with the message "+complaint.getComplaintMessage();
			iEmailService.sendEmail(to, subject, text);
		}
		complaint.setCitizen(citizen);
		complaint.setDepartment(department);
		complaint.setAddress(address);
		Chat chat = createChat(citizenId, departmentId);
		PostFeedback postFeedback = createPostFeedBack();
		complaint.setChatId(chat.getId());
		complaint.setFeedbackPostId(postFeedback.getId());
		complaint.setComplaintStatus(ComplaintStatus.PENDING.toString());
		return complaintRepository.save(complaint);
	}

	// get Address By CitizenId
	public Address getAddressByCitizenId(int addressId) {
		return addressRepository.findById(addressId).orElseThrow(() -> new AdminException("Address not found",HttpStatus.NOT_FOUND));
	}

	// get complaints by citizenId
	public List<Complaint> getAllComplaintsOfCitizen(int citizenId){
		Citizen citizen=this.getUserById(citizenId);
		return complaintRepository.findByCitizen(citizen);
	}

	// send reminder
	@Override
	public Complaint sendReminder(int complaintId) {
		Complaint complaint = complaintRepository.findById(complaintId).orElseThrow(() -> new ComplaintException("Complaint not found", HttpStatus.NOT_FOUND));
		if(complaint.getComplaintStatus().equals(ComplaintStatus.RESOLVED.toString()) || complaint.getComplaintStatus().equals(ComplaintStatus.PENDING.toString())) {
			complaint.setComplaintStatus(ComplaintStatus.REOPENED.toString());
		}
		return complaintRepository.save(complaint);
	}

	//This methid is for getting all the complaint in the complaint table
	@Override
	public List<Complaint> getAllComplaints() {
		return complaintRepository.findAllComplaints();
	}

	@Override
	public List<Citizen> getAllCitizens() {
		return citizenRepository.findAll();
	}

	// reset password (for citizen to reset his account when he is logged in)
	@Override
	public Boolean resetPassword(int citizenId, String password) {
		Citizen citizen = citizenRepository.findById(citizenId).orElse(null);
		if(citizen != null) {
			citizen.setPassword(this.bCryptPasswordEncoder.encode(password));
			citizenRepository.save(citizen);
			return true;

		}else {
			return false;
		}
	}

	//This function will create Chat object in mongoDB and will share the created object with complaint to handle chat betweem Department Head and citizen
	@Override
	public Chat createChat(int citizenId, int departmentId) {
		Chat chat = new Chat();
		chat.setCitizenId(citizenId);
		chat.setDepartmentId(departmentId);
		chat.setMessages(new ArrayList());
		return this.chatRepository.save(chat);
	}


	//This function will create PostFeedback object in mongoDB and will share the created object with register complaint (This will help in handling like dislike and comment)
	@Override
	public PostFeedback createPostFeedBack() {
		PostFeedback feedback = new PostFeedback();
		feedback.setDislikes(new ArrayList<>());
		feedback.setLikes(new ArrayList<>());
		feedback.setPostComments(new ArrayList<>());
		feedback.setRatings(new ArrayList<>());
		return this.feedbackRepository.save(feedback);
	}

	//function will update citizen rmark and store it in mongoDB
	@Override
	public Chat updateCitizenRemark(UpdateRemark updateRemark) {
		Complaint complaint = complaintRepository.findById(updateRemark.getComplaintId()).orElseThrow(() -> new ComplaintException("complaionr does not exist", HttpStatus.NOT_FOUND));
		Chat chat = chatRepository.findById(complaint.getChatId()).orElseThrow(); //TODO: //Exception to be added
		Citizen citizen = complaint.getCitizen();
		List<Messages> messages = chat.getMessages();
		//		chat.setCitizenId(citizen.getCitizenId());
		Messages message = new Messages();
		message.setMessage(updateRemark.getMessage());
		//		message.setDocumentPath(complaint.getDocumentPath());
		message.setSenderRole(citizen.getRole());
		messages.add(message);
		chat.setMessages(messages);
		return chatRepository.save(chat);
	}

	////function will provide all the addresses which user has registered
	public List<Address> getAllCitizenAddress(int citizenId) {
		Citizen citizen = getUserById(citizenId);
		return addressRepository.findByCitizen(citizen);
	}

	@Override
	public Boolean incrementFailedAttempts(String email) {
		Citizen citizen = this.citizenRepository.findByEmail(email);
		if(citizen == null) {
			return false;
		}else {
			if(citizen.getLoginAttempts() <= 2) {
				citizen.setLoginAttempts(citizen.getLoginAttempts()+1);
			}
			else {
				citizen.setActived(false);
			}
			this.citizenRepository.save(citizen);
			return true;
		}
	}

	@Override
	public Boolean resetAttempts(String email) {
		Citizen citizen = this.citizenRepository.findByEmail(email);
		if(citizen == null) {
			return false;
		}else {
			citizen.setLoginAttempts(0);
			citizen.setLastLogin(Instant.now());
			this.citizenRepository.save(citizen);
			return true;
		}

	}

}
