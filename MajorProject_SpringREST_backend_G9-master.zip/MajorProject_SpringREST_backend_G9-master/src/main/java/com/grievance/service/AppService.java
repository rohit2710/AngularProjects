package com.grievance.service;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.grievance.dto.nosql.FeedbackPostDTO;
import com.grievance.dto.nosql.GetPostsDetails;
import com.grievance.dto.nosql.PostCounts;
import com.grievance.entity.Complaint;
import com.grievance.exception.ComplaintException;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.entity.Messages;
import com.grievance.nosql.entity.PostComment;
import com.grievance.nosql.entity.PostFeedback;
import com.grievance.nosql.repository.ChatRepository;
import com.grievance.nosql.repository.PostFeedbackRepository;
import com.grievance.repository.ComplaintRepository;

@Service
public class AppService implements IAppService {

	@Autowired
	private ComplaintRepository complaintRepository;

	@Autowired
	private PostFeedbackRepository feedbackRepository;

	@Autowired
	private ChatRepository chatRepository;

	@Override
	public Complaint getcomplaintById(int complaintId) {
		return complaintRepository.findById(complaintId).orElseThrow(() -> new ComplaintException("No Complaint Found", HttpStatus.NOT_FOUND));
	}

	//this will add comment in post
	@Override
	public PostComment addComment(PostComment postComment, String postFeedbackId) {
		PostFeedback postFeedback = this.feedbackRepository.findById(postFeedbackId).orElseThrow();
		postFeedback.addPostComments(postComment);
		this.feedbackRepository.save(postFeedback);
		return postComment;
	}

	//this will add like to post and return count of total likes
	@Override
	public PostCounts addLike(Integer userId, String feedbackPostId) {
		PostFeedback feedbackPost = this.feedbackRepository.findById(feedbackPostId).orElseThrow();
		feedbackPost.like(userId);
		PostCounts postCounts =  new PostCounts();
		postCounts.setTotalDislike(feedbackPost.getDislikes().size());
		postCounts.setTotalLikes(feedbackPost.getLikes().size());
		this.feedbackRepository.save(feedbackPost);
		return postCounts;
	}

	//this will add dislike to post and return count of total dislikes
	@Override
	public PostCounts addDislike(Integer userId, String feedbackPostId) {
		PostFeedback feedbackPost = this.feedbackRepository.findById(feedbackPostId).orElseThrow();
		feedbackPost.disLike(userId);
		this.feedbackRepository.save(feedbackPost);
		PostCounts postCounts =  new PostCounts();
		postCounts.setTotalDislike(feedbackPost.getDislikes().size());
		postCounts.setTotalLikes(feedbackPost.getLikes().size());
		return postCounts;
	}

	@Override
	public FeedbackPostDTO loadPost(String feedbackPostId) {
		PostFeedback feedbacks  = this.feedbackRepository.findById(feedbackPostId).orElseThrow();
		FeedbackPostDTO feedbackPostDTO = new FeedbackPostDTO();
		feedbackPostDTO.setLikes(feedbacks.getLikes().size());
		feedbackPostDTO.setDislikes(feedbacks.getDislikes().size());
		feedbackPostDTO.setPostComments(feedbacks.getPostComments().size());
		return feedbackPostDTO;
	}

	@Override
	public PostComment addCommets(PostComment postCommet, String feedbackPostId) {
		PostFeedback feedbacksPost  = this.feedbackRepository.findById(feedbackPostId).orElseThrow();
		postCommet.setCommentTime(Instant.now());
		postCommet.setUserId(postCommet.getUserId());
		postCommet.setUserName(postCommet.getUserName());
		feedbacksPost.addPostComments(postCommet);
		this.feedbackRepository.save(feedbacksPost);
		return postCommet;
	}

	//this will return post using id
	@Override
	public GetPostsDetails loadPostById(String feedbackPostId) {
		PostFeedback feedbacks  = this.feedbackRepository.findById(feedbackPostId).orElseThrow();
		GetPostsDetails postDetail = new GetPostsDetails();
		postDetail.setLikes(feedbacks.getLikes());
		postDetail.setDislikes(feedbacks.getDislikes());
		postDetail.setPostComments(feedbacks.getPostComments());
		return postDetail;
	}

	@Override
	public Chat getAllChatMessages(String chatId) {
		return this.chatRepository.findById(chatId).orElseThrow(() -> new RuntimeException());
	}

	//this will add message to chat
	@Override
	public Boolean addChatMessage(Messages message, String chatId) {
		Chat chat = this.chatRepository.findById(chatId).orElseThrow();
		message.setTimestamp(Instant.now());
		chat.addMessage(message);
		this.chatRepository.save(chat);
		return true;
	}

}
