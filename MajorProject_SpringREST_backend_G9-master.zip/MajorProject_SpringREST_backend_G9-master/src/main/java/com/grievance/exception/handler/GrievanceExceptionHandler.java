package com.grievance.exception.handler;

import java.util.Date;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.grievance.exception.AddressException;
import com.grievance.exception.AdminException;
import com.grievance.exception.CitizenException;
import com.grievance.exception.ComplaintException;
import com.grievance.exception.DepartmentException;
import com.grievance.exception.EmployeeException;
import com.grievance.exception.FileStorageException;
import com.grievance.exception.MyFileNotFoundException;

//Centralized exception handler
@ControllerAdvice
public class GrievanceExceptionHandler {

    Logger logger = LogManager.getLogger(GrievanceExceptionHandler.class);
	
	// Exception handling for AdminException class
	@ExceptionHandler(value = { AdminException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(AdminException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		this.logger.warn(e.getMessage());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for CitizenException class
	@ExceptionHandler(value = { CitizenException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(CitizenException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for ComplaintException class
	@ExceptionHandler(value = { ComplaintException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(ComplaintException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for DepartmentException class
	@ExceptionHandler(value = { DepartmentException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(DepartmentException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for EmployeeException class
	@ExceptionHandler(value = { EmployeeException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(EmployeeException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for AddressException class
	@ExceptionHandler(value = { AddressException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(AddressException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for FileStorageException class
	@ExceptionHandler(value = { FileStorageException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(FileStorageException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}

	// Exception handling for MyFileNotFoundException class
	@ExceptionHandler(value = { MyFileNotFoundException.class })
	public ResponseEntity<ErrorResponse> handleApiReQuestException(MyFileNotFoundException e) {
		HttpStatus httpStatus = e.getHttpStatus() != null ? e.getHttpStatus() : HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), e.getMessage(), e.getPath());
		return ResponseEntity.status(httpStatus).body(errorResponse);
	}
	
}
