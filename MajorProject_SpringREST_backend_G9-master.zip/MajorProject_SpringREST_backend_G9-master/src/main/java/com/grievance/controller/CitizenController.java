package com.grievance.controller;

import java.util.ArrayList;
import java.util.List;
import javax.mail.MessagingException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.grievance.dto.AddressDTO;
import com.grievance.dto.CitizenComplaintDTO;
import com.grievance.dto.ComplaintAddress;
import com.grievance.dto.ComplaintRegisterDTO;
import com.grievance.dto.ShowCitizenDTO;
import com.grievance.dto.UpdateRemark;
import com.grievance.dto.PublicComplaintsDTO;
import com.grievance.entity.Address;
import com.grievance.entity.Complaint;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.repository.PostFeedbackRepository;
import com.grievance.service.ICitizenService;

@RestController
@RequestMapping("/api/citizen")
@CrossOrigin(origins = "*")
public class CitizenController {

	private static final Logger logger = LogManager.getLogger(CitizenController.class);

	@Autowired
	private ModelMapper modelMapper; //modal mapper to map entity with the DTO (This reduces the use of setter)

	@Autowired
	private ICitizenService citizenService;

	@Autowired
	PostFeedbackRepository feedbackRepository;

	// this method registers complaint given by logged in user.
	@PostMapping(value = "/complaint/{citizenId}")
	public ResponseEntity<Complaint> registerComplaint(@RequestBody ComplaintRegisterDTO complaintDto, 
			@PathVariable int citizenId) throws MessagingException{
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT); //model mapper used to map two classes STRICT
		Complaint complaint=modelMapper.map(complaintDto,Complaint.class);
		complaint=citizenService.registerComplaint(complaint, citizenId,
				complaintDto.getDepartmentId(),complaintDto.getAddressId());
		logger.info("complaint registered successfully against citizenId : "+citizenId);
		return ResponseEntity.status(HttpStatus.OK).body(complaint);
	}

	// this method will populate complaints which are registered by logged in user.
	@GetMapping(value = "/complaints/{citizenId}")
	public ResponseEntity<List<CitizenComplaintDTO>>getAllComplaints(@PathVariable int citizenId){
		List<Complaint> complaints = citizenService.getAllComplaintsOfCitizen(citizenId);
		List<CitizenComplaintDTO> complaintsDTO=new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.LOOSE);//model mapper used to map two classes LOOSE
		for(Complaint complaint : complaints) {
			CitizenComplaintDTO complaintDTO=modelMapper.map(complaint,CitizenComplaintDTO.class);
			complaintDTO.setAddressDTO(modelMapper.map(complaint.getAddress(), AddressDTO.class));
			if(complaint.getDepartment()!=null) {
				complaintDTO.setDepartmentName(complaint.getDepartment().getDepartmentName());
			}
			complaintDTO.setCitizenDTO(modelMapper.map(complaint.getCitizen(), ShowCitizenDTO.class));
			complaintsDTO.add(complaintDTO);
		}
		return ResponseEntity.status(HttpStatus.OK).body(complaintsDTO);
	}

	// this will send reminder in case if citizen is not satisfied with resolution
	@PutMapping(value = "/reminder/{complaintId}")
	public ResponseEntity<Boolean> sendReminder(@PathVariable int complaintId){
		Complaint complaint = citizenService.sendReminder(complaintId);
		if(complaint!=null) {
			logger.info("Send reminder successfull");
			return ResponseEntity.status(HttpStatus.OK).body(true);
		}else {
			logger.error("Send reminder failed");
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}

	//This function will show all the complaints to the logged in citizen to share his review on the complaint
	@GetMapping(value = "/complaints")
	public ResponseEntity<List<PublicComplaintsDTO>> getPublicComplaints(){
		List<Complaint> complaints = citizenService.getAllComplaints();
		List<PublicComplaintsDTO> showPublicComplaintsDTOs = new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		if(complaints !=null) {
			for(Complaint complaint:complaints) {
				PublicComplaintsDTO showPublicComplaintsDTO= modelMapper.map(complaint, PublicComplaintsDTO.class);
				showPublicComplaintsDTO.setCitizenName(complaint.getCitizen().getName());
				showPublicComplaintsDTO.setDepartmentName(complaint.getDepartment().getDepartmentName());
				showPublicComplaintsDTOs.add(showPublicComplaintsDTO);
			}
		}
		if(showPublicComplaintsDTOs != null) {
			return ResponseEntity.status(HttpStatus.OK).body(showPublicComplaintsDTOs);
		}
		return null;	
	}

	@PutMapping(value = "/citizen/remark")
	public ResponseEntity<Boolean> updateCitizenRemark(@RequestBody UpdateRemark updateRemark){
		Chat chat = citizenService.updateCitizenRemark(updateRemark);
		if(chat !=null)
		{
			return ResponseEntity.status(HttpStatus.CREATED).body(true);
		}
		else
		{
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}

	//function give all the address citizen has during registering complaint

	@GetMapping("/citizen/{citizenId}/addresses")
	public ResponseEntity<List<ComplaintAddress>> getAllCitizenAddress(@PathVariable int citizenId){
		List<Address> addresses = citizenService.getAllCitizenAddress(citizenId); 
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		List<ComplaintAddress> complaintAddresses = new ArrayList<>();
		for(Address address: addresses) {//mapping Entity to DTO
			ComplaintAddress complaintAddress = modelMapper.map(address, ComplaintAddress.class);
			complaintAddresses.add(complaintAddress);
		}
		return ResponseEntity.status(HttpStatus.OK).body(complaintAddresses);
	}
}
