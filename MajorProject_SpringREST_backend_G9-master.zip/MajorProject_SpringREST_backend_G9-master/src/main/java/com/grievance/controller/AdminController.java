package com.grievance.controller;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grievance.dto.CitizenComplaintDTO;
import com.grievance.dto.ComplaintDTO;
import com.grievance.dto.DeactiveUser;
import com.grievance.dto.DepartmentRegisterDTO;
import com.grievance.dto.EmployeeDTO;
import com.grievance.dto.EmployeeRegistrationDTO;
import com.grievance.dto.GraphDataDTO;
import com.grievance.dto.ShowCitizenDTO;
import com.grievance.dto.UpdateEmployeeDTO;
import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.entity.Department;
import com.grievance.entity.Employee;
import com.grievance.exception.AdminException;
import com.grievance.service.IAdminService;
import com.grievance.service.IAuthenticationService;
import com.grievance.service.IComplaintService;

@RestController
@RequestMapping(value="/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

	private static final Logger logger = LogManager.getLogger(AdminController.class);
	@Autowired
	private ModelMapper modelMapper; //modal mapper to map entity with the DTO (This reduces the use of setter)

	@Autowired
	private IAdminService iAdminService;

	@Autowired
	private IComplaintService complaintService;

	//Register Employee Method
	@PostMapping(value = "/employee")
	public ResponseEntity<Employee> registerEmployee(@RequestBody EmployeeRegistrationDTO employeeRegistration) throws MessagingException {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT); //modal mapper to map object with DTO
		Employee employee = modelMapper.map(employeeRegistration, Employee.class);
		employee = iAdminService.registerEmployee(employee, employeeRegistration.getDepartmentId());
		logger.info("employee registered successfully with department name : "+employee.getName());
		return ResponseEntity.status(HttpStatus.OK).body(employee);
	}
	//Register Department Method
	@PostMapping(value = "/department")
	public ResponseEntity<Department> registerDepartment(@RequestBody DepartmentRegisterDTO departmentRegister) {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Department department = modelMapper.map(departmentRegister, Department.class);
		department = iAdminService.registerDepartment(department);
		logger.info("department registered successfully with department name : "+department.getDepartmentName());
		return ResponseEntity.status(HttpStatus.OK).body(department);
	}

	//Get All Complaints Registered
	@GetMapping("/complaints/{pageNo}/{itemsPerPage}")
	public ResponseEntity<List<CitizenComplaintDTO>> getAllComplaints(@PathVariable Integer pageNo,
			@PathVariable Integer itemsPerPage){
		pageNo = pageNo == null ? 0:pageNo;
		itemsPerPage = itemsPerPage == null ? 3:itemsPerPage;
		Pageable page = PageRequest.of(pageNo, itemsPerPage);
		Page<Complaint> complaint = iAdminService.getAllComplaints(page);
		List<CitizenComplaintDTO> citizenCompalintsDto = new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		for(Complaint c: complaint) {
			CitizenComplaintDTO citizenCompalintDto = modelMapper.map(c, CitizenComplaintDTO.class);
			ShowCitizenDTO showCitizenDto = modelMapper.map(c.getCitizen(), ShowCitizenDTO.class);
			citizenCompalintDto.setCitizenDTO(showCitizenDto);
			if(c.getDepartment()!=null) {
				citizenCompalintDto.setDepartmentName(c.getDepartment().getDepartmentName());
			}
			//			citizenCompalintDto.setAddressDTO(c.getAddress());
			citizenCompalintsDto.add(citizenCompalintDto);	
		}
		return ResponseEntity.status(HttpStatus.OK).body(citizenCompalintsDto);
	}

	//it will return list of all departments
	@GetMapping(value = "/departments")
	public ResponseEntity<List<Department>> getAllDepartment() {  //TODO We have to use dto insted entity 
		List<Department> getAllDepartments = iAdminService.getAllDepartments();
		return ResponseEntity.status(HttpStatus.OK).body(getAllDepartments);
	}

	//update department
	@PutMapping(value = "/department/{departmentId}")
	public ResponseEntity<Boolean> updateDepartment(@RequestBody DepartmentRegisterDTO departmentRegisterDTO, @PathVariable int departmentId){
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Department department = modelMapper.map(departmentRegisterDTO, Department.class);
		Department department1 = iAdminService.updateDepartment(department, departmentId);
		if(department1 != null) {
			logger.info("successfuly updated department with id : "+departmentId);
			return ResponseEntity.status(HttpStatus.CREATED).body(true);
		}else {
			logger.error("Department updation failed");
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}

	//update employee
	@PutMapping(value = "/employee/{employeeId}/{departmentId}")
	public ResponseEntity<Boolean> updateEmployee(@RequestBody UpdateEmployeeDTO updateEmployeeDTO , @PathVariable int employeeId, @PathVariable int departmentId){
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Employee employee = modelMapper.map(updateEmployeeDTO, Employee.class);	
		Boolean updateStatus = iAdminService.updateEmployee(employee, employeeId, departmentId);
		if(Boolean.TRUE.equals(updateStatus)) {
			logger.info("successfuly updated employee with id : "+employeeId);
			return ResponseEntity.status(HttpStatus.OK).body(true);
		}else {
			logger.error("Employee updation failed");
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}

	//delete department
	@DeleteMapping(value = "/department/{departmentId}")
	public ResponseEntity<Boolean> deleteDepartment(@PathVariable int departmentId){
		Boolean isDeleted = iAdminService.deleteDepartment(departmentId);
		if(isDeleted.equals(Boolean.TRUE)) {
			logger.info("successfuly deleted department with id : "+departmentId);
			return ResponseEntity.status(HttpStatus.OK).body(isDeleted);
		}
		logger.error("Department deletion failed");
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(isDeleted);
	}

	//it will return department info using departmentId
	@GetMapping("/department/{departmentId}")
	public ResponseEntity<Department> getDepartmentById(@PathVariable int departmentId) {
		Department department = iAdminService.getDepartment(departmentId);
		logger.info("successfuly got department with id : "+departmentId);
		return ResponseEntity.status(HttpStatus.OK).body(department);
	}

	//get all employee (manage employee)
	@GetMapping(value = "/employees")
	public ResponseEntity<List<EmployeeDTO>> getAllEmployee(){
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		List<Employee> employees = iAdminService.getAllEmployee();
		List<EmployeeDTO> employeeDTOs = new ArrayList<>();
		for(Employee emp: employees) {
			EmployeeDTO employee = modelMapper.map(emp, EmployeeDTO.class);
			Department department=emp.getDepartment();
			if(department == null) {
				employee.setDepartmentName("NOT ASSIGNED");
			}else {
				employee.setDepartmentName(department.getDepartmentName());
			}
			employeeDTOs.add(employee);
		}
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(employeeDTOs);
	}

	//it will return employee info
	@GetMapping(value = "/employee/{employeeId}")
	public ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable int employeeId ){
		Employee employee = iAdminService.getEmployeeById(employeeId);
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		EmployeeDTO employeeDto = modelMapper.map(employee, EmployeeDTO.class);	
		logger.info("successfuly got employee with id : "+employeeId);
		return ResponseEntity.status(HttpStatus.OK).body(employeeDto);
	}

	//it will return list of complaints which are not assigned to any department
	@GetMapping(value="/floatingcomplaints")
	public ResponseEntity<List<ComplaintDTO>> getAllComplaintWithNoDepartment(){
		List<Complaint> complaints=iAdminService.getAllComplaintWithNoDepartment();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		List<ComplaintDTO> compalintsDto = new ArrayList<>();
		for(Complaint c: complaints) {
			if(c.getDepartment() == null) {
				ComplaintDTO complaintDto = modelMapper.map(c, ComplaintDTO.class);
				ShowCitizenDTO showCitizenDto = modelMapper.map(c.getCitizen(), ShowCitizenDTO.class);
				complaintDto.setShowCitizen(showCitizenDto);
				//			complaintDto.setAddress(address);
				compalintsDto.add(complaintDto);
			}
		}
		return ResponseEntity.status(HttpStatus.OK).body(compalintsDto);
	}

	//it will return complaint count accoding to complaint status
	@GetMapping(value = "getCountByStatus/{complaintStatus}")
	public ResponseEntity<Long> getCountByStatus(@PathVariable String complaintStatus ){
		return ResponseEntity.status(HttpStatus.OK).body(this.iAdminService.getComplaintCount(complaintStatus));
	}



	//graphRelated
	@GetMapping(value = "getGraphDataByDepartment/{departmentId}")
	public ResponseEntity<GraphDataDTO> getGraphDataByDepartment(@PathVariable Integer departmentId ){
		return ResponseEntity.status(HttpStatus.OK).body(this.complaintService.getDataByDepartment(departmentId));
	}

	@GetMapping(value = "getAllGraphData")
	public ResponseEntity<GraphDataDTO> getAllGraphData(){
		return ResponseEntity.status(HttpStatus.OK).body(this.complaintService.getAllData());
	}

	//it will return list of locked accounts
	@GetMapping(value =  "/lockedaccount")
	public ResponseEntity<List<DeactiveUser>> getAllDeactiveUser(){
		List<Citizen> citizens = iAdminService.getAllDeactiveCitizen();
		List<Employee> employees = iAdminService.getAllDeactiveEmloyee();
		List<DeactiveUser> deactiveUsers = new ArrayList<>();
		if(citizens !=null) {
			for(Citizen citizen : citizens) {
				DeactiveUser deactiveUser = new DeactiveUser();
				deactiveUser.setEmail(citizen.getEmail());
				deactiveUser.setRole(citizen.getRole());
				deactiveUser.setName(citizen.getName());
				deactiveUsers.add(deactiveUser);
			}
		}
		if(employees !=null) {
			for(Employee employee : employees) {
				DeactiveUser deactiveUser = new DeactiveUser();
				deactiveUser.setEmail(employee.getEmail());
				deactiveUser.setRole(employee.getRole());
				deactiveUser.setName(employee.getName());
				deactiveUsers.add(deactiveUser);
			}
		}
		return ResponseEntity.status(HttpStatus.OK).body(deactiveUsers);
	}

	//it will activate user account
	@PutMapping("/active/{email}")
	public ResponseEntity<Boolean> activateAccount(@PathVariable String email){
		Boolean status = iAdminService.ActiveAccount(email);
		if(Boolean.TRUE.equals(status)) {
			return ResponseEntity.status(HttpStatus.OK).body(true);
		}
		else {
			return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(false);
		}
	}

	//it will return list of complaints using department name 
	@GetMapping(value="complaints/{departmentName}")
	public ResponseEntity<List<CitizenComplaintDTO>> getComplaintByDepartmentName(@PathVariable String departmentName){
		List<Complaint> complaints = iAdminService.getComplaintByDepartmentName(departmentName);
		List<CitizenComplaintDTO> citizenCompalintsDto = new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		for(Complaint c: complaints) {
			CitizenComplaintDTO citizenCompalintDto = modelMapper.map(c, CitizenComplaintDTO.class);
			ShowCitizenDTO showCitizenDto = modelMapper.map(c.getCitizen(), ShowCitizenDTO.class);
			citizenCompalintDto.setCitizenDTO(showCitizenDto);
			citizenCompalintDto.setDepartmentName(c.getDepartment().getDepartmentName());
			citizenCompalintsDto.add(citizenCompalintDto);	
		}
		return ResponseEntity.status(HttpStatus.OK).body(citizenCompalintsDto);

	}

}
