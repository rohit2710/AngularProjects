package com.grievance.controller;

import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.grievance.dto.ComplaintDTO;
import com.grievance.dto.GraphDataDTO;
import com.grievance.dto.ShowCitizenDTO;
import com.grievance.dto.StatusCountDTO;
import com.grievance.dto.UpdateRemark;
import com.grievance.entity.Complaint;
import com.grievance.entity.Employee;
import com.grievance.nosql.entity.Chat;
import com.grievance.service.IComplaintService;
import com.grievance.service.IDepartmentService;

@RestController
@RequestMapping("/api/department")
@CrossOrigin(origins = "*")
public class DepartmentController {
	private static final Logger logger = LogManager.getLogger(DepartmentController.class);

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	private IDepartmentService departmentService;

	@Autowired
	private IComplaintService complaintService;

	//get All Complaints for a Particular Department
	@GetMapping("/complaints/{employeeId}/{pageNo}/{itemsPerPage}")
	public ResponseEntity<List<ComplaintDTO>> getComplaintsOfDepartmentById(@PathVariable int employeeId, @PathVariable Integer pageNo,
			@PathVariable Integer itemsPerPage){
		pageNo = pageNo == null ? 0:pageNo;
		itemsPerPage = itemsPerPage == null ? 3:itemsPerPage;
		Pageable page = PageRequest.of(pageNo, itemsPerPage);
		Employee employee = departmentService.getDepartmentById(employeeId);
		List<Complaint> complaint = departmentService.getComplaintsOfDepartmentById(employee.getDepartment().getDepartmentId(),page);
		List<ComplaintDTO> compalintsDto = new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		for(Complaint c: complaint) {
			ComplaintDTO complaintDto = modelMapper.map(c, ComplaintDTO.class);
			ShowCitizenDTO showCitizenDto = modelMapper.map(c.getCitizen(), ShowCitizenDTO.class);
			complaintDto.setShowCitizen(showCitizenDto);
			//			complaintDto.setAddress(address);
			compalintsDto.add(complaintDto);	
		}
		return ResponseEntity.status(HttpStatus.OK).body(compalintsDto);
	}

	//get All Complaints for a Particular Department According to status 
	@GetMapping("/complaintsBystatus/{employeeId}/{pageNo}/{itemsPerPage}/{status}")
	public ResponseEntity<List<ComplaintDTO>> getComplaintsOfDepartmentByEmployeeIdAndStatus(@PathVariable int employeeId,@PathVariable String status, @PathVariable Integer pageNo,
			@PathVariable Integer itemsPerPage){
		pageNo = pageNo == null ? 0:pageNo;
		itemsPerPage = itemsPerPage == null ? 3:itemsPerPage;
		Pageable page = PageRequest.of(pageNo, itemsPerPage);
		Employee employee = departmentService.getDepartmentById(employeeId);
		List<Complaint> complaint = departmentService.getComplaintsByDepartmentAndStatus(status, employee.getDepartment().getDepartmentId(),page);
		List<ComplaintDTO> compalintsDto = new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		for(Complaint c: complaint) {
			ComplaintDTO complaintDto = modelMapper.map(c, ComplaintDTO.class);
			ShowCitizenDTO showCitizenDto = modelMapper.map(c.getCitizen(), ShowCitizenDTO.class);
			complaintDto.setShowCitizen(showCitizenDto);
			compalintsDto.add(complaintDto);	
		}
		return ResponseEntity.status(HttpStatus.OK).body(compalintsDto);
	}


	//Update Status for a particular Complaint
	@PutMapping("/status/{id}/{status}")
	public ResponseEntity<Complaint> updateStatus(@PathVariable(value="id") int complaintid, @PathVariable(value="status") String status){
		Complaint complaints= departmentService.updateStatus(complaintid,status);
		logger.info("Department status updated successfully");
		return new ResponseEntity<Complaint>(complaints,HttpStatus.OK);
	}

	//Transfer Complaint from one Department to another  

	@PutMapping("/transfer/{newdepartmentId}/{complaintId}")
	public ResponseEntity<Complaint> transferComplaint(@PathVariable(value="newdepartmentId") int newDepartmentId, @PathVariable(value="complaintId") int complaintId){
		Complaint complaints= departmentService.transferComplaint(complaintId, newDepartmentId);
		logger.info("complaint transfered successfully with complaintId: "+complaintId);
		return new ResponseEntity<Complaint>(complaints,HttpStatus.OK);
	}

	//update the Head Remark on perticular complaint
	@PutMapping(value = "/remark")
	public ResponseEntity<Boolean> updateDepartmentHeadRemark(@RequestBody UpdateRemark updateRemark){
		Chat chat = departmentService.updateDepartmentHeadRemark(updateRemark);
		if(chat !=null)
		{
			return ResponseEntity.status(HttpStatus.CREATED).body(true);
		}
		else
		{
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}
	@GetMapping(value= "/statusCount/{complaintStatus}")
	public ResponseEntity<StatusCountDTO> getComplaintStatusCount(@PathVariable String complaintStatus){
		StatusCountDTO statusCount= new StatusCountDTO();
		statusCount.setStatus(complaintStatus);
		statusCount.setCount(this.departmentService.countByComplaintStatus(complaintStatus));
		return new ResponseEntity<StatusCountDTO>(statusCount,HttpStatus.OK);
	}

	//graphRelated
	@GetMapping(value = "getDataByDeptId/{departmentId}")
	public ResponseEntity<GraphDataDTO> getDataByDepartmentId(@PathVariable Integer departmentId ){
		return ResponseEntity.status(HttpStatus.OK).body(this.complaintService.getDataByEmployeeId(departmentId));
	}
}
