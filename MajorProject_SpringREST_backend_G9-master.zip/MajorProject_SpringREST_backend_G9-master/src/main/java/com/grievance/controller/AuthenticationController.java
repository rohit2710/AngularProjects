package com.grievance.controller;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.naming.AuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.grievance.dto.CitizenRegistration;
import com.grievance.dto.JwtResponce;
import com.grievance.dto.ResetPassword;
import com.grievance.dto.UpdatePassword;
import com.grievance.dto.ValidateOtpDTO;
import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Employee;
import com.grievance.entity.UserRole;
import com.grievance.exception.handler.GrievanceExceptionHandler;
import com.grievance.security.LoginUser;
import com.grievance.security.TokenProvider;
import com.grievance.service.IAuthenticationService;
import com.grievance.service.ICitizenService;
import com.grievance.service.IDepartmentService;
import com.grievance.service.IEmailService;
import com.grievance.security.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthenticationController {
	private static final Logger logger = LogManager.getLogger(AuthenticationController.class);

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private TokenProvider jwtTokenUtil;

	@Autowired
	private ModelMapper modelMapper; // modal mapper to map entity with the DTO (This reduces the use of setter)

	@Autowired
	private IEmailService iEmailService;

	@Autowired
	private IAuthenticationService iAuthenticationService;

	@Autowired 
	private ICitizenService citizenService;

	@Autowired
	private IDepartmentService departmentService;

	// citizen registration
	@PostMapping(value = "/register")
	public ResponseEntity<Citizen> registerCitizen(@RequestBody CitizenRegistration citizenRegistration)
			throws MessagingException {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Citizen citizen = modelMapper.map(citizenRegistration.getCitizenDTO(), Citizen.class);
		Address address = modelMapper.map(citizenRegistration.getAddressDTO(), Address.class);
		citizen = iAuthenticationService.registerCitizen(citizen, address);
		this.logger.info("Dddd");
		if(citizen !=null) {
			Boolean status = this.iEmailService.sendOtpForAccountActivation(citizen);
			if(Boolean.TRUE.equals(status)) {
				logger.info("citizen registered successfully with citizen name : "+citizen.getName());
				return ResponseEntity.status(HttpStatus.OK).body(citizen);
			} else {
				throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, "OTP could not be send please try again");
			}
		}else {
			logger.error("citizen registration failed");
		}
		throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Citizen Could not create");
	}


	// send otp
	@GetMapping(value = "/authentication/{citizenId}")
	public ResponseEntity<String> sendOTP(@PathVariable int citizenId) throws MessagingException {
		this.iEmailService.addOTP(citizenId);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body("otp sent successfully");
	}

	// validate email (This function will be called when user is registering him
	// self to check the email he/she has entered is already present in the database
	// )
	@GetMapping(value = "/validate/{email}")
	public ResponseEntity<Boolean> validateEmail(@PathVariable String email) {
		Citizen citizen = iAuthenticationService.validateEmail(email);
		if (citizen != null) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(false);
		} else {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(true);
		}
	}

	// check and send email to the user for (reseting the password)forget password
	@GetMapping(value = "/forgetpassword/{email}")
	public ResponseEntity<Boolean> sendOtp(@PathVariable String email) throws MessagingException {
		Citizen citizen = iAuthenticationService.validateEmail(email);
		if (citizen != null) {
			this.iEmailService.addOTP(citizen.getCitizenId());
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(true);
		} else {
			Employee employee = iAuthenticationService.validateEmployeeEmail(email);
			if (employee != null) {
				this.iEmailService.addOTP(employee.getEmployeeId());
				return ResponseEntity.status(HttpStatus.ACCEPTED).body(true);
			} else {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
			}
		}
	}

	// otp validation (during the forget password user willl enter the email he has
	// received through email that otp will be verified here)
	@PostMapping(value = "/validate")
	public ResponseEntity<Boolean> validateOtp(@RequestBody ValidateOtpDTO validateOtpDTO) {
		Boolean valdation = iAuthenticationService.validateOtp(validateOtpDTO);
		if (Boolean.TRUE.equals(valdation)) {
			return ResponseEntity.status(HttpStatus.OK).body(true);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(false);
		}
	}

	// forget password method
	// after verification of otp and email update password will execute
	@PutMapping(value = "/password")
	public ResponseEntity<Boolean> updatePassword(@RequestBody UpdatePassword updatePassword) {
		logger.info("password updated successfully");
		return ResponseEntity.status(HttpStatus.OK).body(this.iAuthenticationService.updatePassword(updatePassword));

	}


	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> register(@RequestBody LoginUser loginUser ) throws AuthenticationException {

		final org.springframework.security.core.Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(
						loginUser.getUsername(),
						loginUser.getPassword()
						)
				);
		this.logger.info("Dddd");
		SecurityContextHolder.getContext().setAuthentication(authentication);
		final String token = jwtTokenUtil.generateToken(authentication);
		UserDetails principal = (UserDetails)authentication.getPrincipal();
		Collection<? extends GrantedAuthority> authority = principal.getAuthorities();
		List<String> roles = authority.stream().map(r -> r.getAuthority()).collect(Collectors.toList());
		JwtResponce jwtResponce = new JwtResponce();
		jwtResponce.setEmail(principal.getUsername());
		jwtResponce.setRoles(roles);
		jwtResponce.setToken(token);

		if(roles.contains(UserRole.ADMIN.toString()) || roles.contains(UserRole.DEPARTMENTHEAD.toString())) {
			Employee employee = iAuthenticationService.getEmployeeByEmail(principal.getUsername());
			jwtResponce.setUserId(employee.getEmployeeId());
			jwtResponce.setName(employee.getName());
			departmentService.resetAttempts(principal.getUsername());
			return ResponseEntity.ok(jwtResponce);
		}else {
			Citizen citizen = iAuthenticationService.getCitizenByEmail(principal.getUsername());
			jwtResponce.setUserId(citizen.getCitizenId());
			jwtResponce.setName(citizen.getName());
			citizenService.resetAttempts(principal.getUsername());
			return ResponseEntity.ok(jwtResponce);
		}
	}
	// this will reset the password id citizen wants to change it
	@PutMapping(value = "/changepassword")
	public ResponseEntity<Boolean> resetPassword(@RequestBody ResetPassword resetPassword){
		Boolean citizenStatus =  citizenService.resetPassword(resetPassword.getUserId(), resetPassword.getPassword());
		if(Boolean.TRUE.equals(citizenStatus)) {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(true);
		}else {
			Boolean employeeStatus = departmentService.resetPassword(resetPassword.getUserId(), resetPassword.getPassword());
			if(Boolean.TRUE.equals(employeeStatus)) {

				return ResponseEntity.status(HttpStatus.ACCEPTED).body(true);
			}else {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User Not found");
			}
		}
	}

	//this will activate account
	@PutMapping(value = "/activate")
	public ResponseEntity<Boolean> ActivateAccount(@RequestBody ValidateOtpDTO validateOtpDTO){
		Boolean status = iAuthenticationService.activateAccount(validateOtpDTO);

		if(Boolean.TRUE.equals(status)) {
			return ResponseEntity.status(HttpStatus.OK).body(true);
		}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(false);
		}
	}


	@GetMapping(value = "/resent/{email}")
	public ResponseEntity<Boolean> resendOTP(@PathVariable String email) throws MessagingException {
		Citizen citizen = iAuthenticationService.getCitizenByEmail(email);
		if (citizen != null) {
			Boolean status = this.iEmailService.sendOtpForAccountActivation(citizen);
			if (Boolean.TRUE.equals(status)) {

				return ResponseEntity.status(HttpStatus.OK).body(true);
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
			}
		}else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Citizen not found");
		}
	}
}
