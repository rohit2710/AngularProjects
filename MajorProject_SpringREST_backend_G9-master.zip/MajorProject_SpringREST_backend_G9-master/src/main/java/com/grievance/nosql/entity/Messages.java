package com.grievance.nosql.entity;

import java.time.Instant;

public class Messages {
	private String message;
	private Integer senderId;
	private String senderRole;
	private String senderName;
	private String documentPath;
	private Instant timestamp;

	public Messages() {
		super();

	}

	public Messages(String message, String documentPath, Instant timestamp) {
		super();
		this.message = message;
		this.documentPath = documentPath;
		this.timestamp = timestamp;
	}



	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public Instant getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}

	public Integer getSenderId() {
		return senderId;
	}

	public void setSenderId(Integer senderId) {
		this.senderId = senderId;
	}

	public String getSenderRole() {
		return senderRole;
	}

	public void setSenderRole(String senderRole) {
		this.senderRole = senderRole;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	@Override
	public String toString() {
		return "Messages [message=" + message + ", senderId=" + senderId + ", senderRole=" + senderRole
				+ ", senderName=" + senderName + ", documentPath=" + documentPath + ", timestamp=" + timestamp + "]";
	}




}
