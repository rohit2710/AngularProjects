package com.grievance.nosql.entity;

import java.time.Instant;

public class PostComment {
	private Integer userId;
	private String userName;
	private String message;
	private Instant commentTime;

	public PostComment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PostComment(Integer userId, String userName, String message, Instant commentTime) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.message = message;
		this.commentTime = commentTime;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Instant getCommentTime() {
		return commentTime;
	}

	public void setCommentTime(Instant commentTime) {
		this.commentTime = commentTime;
	}

	@Override
	public String toString() {
		return "PostComment [userId=" + userId + ", userName=" + userName + ", message=" + message + ", commentTime="
				+ commentTime + "]";
	}

}
