package com.grievance.test;


import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.grievance.entity.Department;
import com.grievance.entity.Employee;
import com.grievance.repository.AddressRepository;
import com.grievance.repository.CitizenRepository;
import com.grievance.repository.ComplaintRepository;
import com.grievance.repository.DepartmentRepository;
import com.grievance.repository.EmployeeRepository;
import com.grievance.service.AdminService;
import com.grievance.service.CitizenService;

public class TestAdmin {

	@InjectMocks
	private AdminService adminService;
	
    @InjectMocks
    private CitizenService citizenService = new CitizenService();
	
    @Mock
    ComplaintRepository complaintRepository;
    
	@Mock
	private DepartmentRepository departmentRepository;

	@Mock
	private EmployeeRepository employeeRepository;
	
	@Mock
	private CitizenRepository citizenRepository;

	@MockBean
	private AddressRepository addressRepository;
	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

//	@Disabled
    @Test
    public void testRegisterEmployee() {
    	Department department = new Department("water", "this is water department");
    	Employee employee =new Employee("rohit", "rohit@12", "123456", "ADMIN", "9638852741");
		employee.setLoginAttempts(0);
		employee.setDepartment(department);
		employee.setPassword(employee.getPassword());
		when(departmentRepository.save(department)).thenReturn(department);
		Department dept =adminService.registerDepartment(department);
		assertEquals(department, dept);
		List<Employee> empList=new ArrayList<Employee>();
		empList.add(employee);
		assertEquals(1, empList.size());
    }
    
//	@Disabled
	@Test
	public void testRegisterDepartment() {
    	Department department = new Department("water", "this is water department");
		when(departmentRepository.save(department)).thenReturn(department);
		Department dept =adminService.registerDepartment(department);
		assertEquals(department, dept);
	}
	
//	@Disabled
	@Test
	public void getAllDepartments() { 
		List<Department> departments = new ArrayList();
		departments.add(new Department("election","This department is about election"));
		departments.add(new Department("water","This department is about water"));
		List<Department> dept=new ArrayList<>(departments);
		Mockito.when(departmentRepository.findAll()).thenReturn(departments);
		dept=departmentRepository.findAll();
		assertNotEquals(2, dept.size());
	}
	
//	@Disabled	
	@Test
	public void testGetAllEmployee() {
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee("rohit1", "rohit@12", "123456", "DEPARTMENTHEAD", "9638852741"));
		employees.add(new Employee("rohit2", "rohit@12", "123456", "DEPARTMENTHEAD", "9638852741"));
		employees.add(new Employee("rohit3", "rohit@12", "123456", "ADMIN", "9638852741"));
		List<Employee> emps=new ArrayList<Employee>();
		Mockito.when(employeeRepository.findAll()).thenReturn(employees);
		emps=employeeRepository.findAll();
		assertEquals(3, emps.size());
	}
	
	//@Disabled
	@Test
	public void testDeleteDepartment() {
		Department department =new Department("election","This department is about election");
		Boolean isDelete=false;
		if(department!=null){
			departmentRepository.delete(department);
			isDelete= true;
		}
		assertEquals(true, isDelete);
	}
	
//	@Disabled
	@Test
	public void testUpdateDepartment() {
    	Department department = new Department("water", "this is water department");
    	department.setDepartmentName("road");
    	department.setDescription("this is road department");
    	Mockito.when(departmentRepository.save(department)).thenReturn(department);
    	assertEquals("this is road department",department.getDescription());
		assertEquals("road", department.getDepartmentName());
	}
}
