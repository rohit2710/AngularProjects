package com.grievance.test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.repository.CitizenRepository;
import com.grievance.repository.ComplaintRepository;
import com.grievance.service.CitizenService;

public class TestCitizen {
	@InjectMocks
	CitizenService citizenService;
	
	@Mock
	CitizenRepository citizenRepository;

	@Mock
	ComplaintRepository complaintRepository;
	

	
	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}
	@Test
	public void testGetAllComplaints(){
		List<Complaint> complaints = new ArrayList<Complaint>();
		complaints.add(new Complaint("water is not coming", "./abc.png"));
		complaints.add(new Complaint("Valve is damaged", "./xyz.png"));
		List<Complaint> list = new ArrayList<Complaint>();
		Mockito.when(complaintRepository.findAll()).thenReturn(complaints);
		list = complaintRepository.findAll();
		assertEquals(2, complaints.size());
	}
	
	@Test
	public void sendReminder() {
		Complaint complaint = new Complaint("water is not coming", "./abc.png");
		complaint.setComplaintId(1);
		complaint.setComplaintStatus("RESOLVED");
		if(complaint.getComplaintStatus().equals("RESOLVED")) {
			complaint.setComplaintStatus("REOPENED");
		}
		assertEquals("REOPENED", complaint.getComplaintStatus());
	}

	@Test
	public void testGetAllEmployee() {
		List<Citizen> citizens = new ArrayList<Citizen>();
		citizens.add(new Citizen("rohit1", "rohit@12", "123456", "CITIZEN", "9638527410", "1234567890"));
		citizens.add(new Citizen("rohit2", "rohit@12", "123456", "CITIZEN", "9638527410", "1234567890"));
		citizens.add(new Citizen("rohit3", "rohit@12", "123456", "CITIZEN", "9638527410", "1234567890"));
		List<Citizen> list = new ArrayList<Citizen>();
		Mockito.when(citizenRepository.findAll()).thenReturn(citizens);
		list = citizenRepository.findAll();
		assertEquals(3, list.size());
	}
	
}
