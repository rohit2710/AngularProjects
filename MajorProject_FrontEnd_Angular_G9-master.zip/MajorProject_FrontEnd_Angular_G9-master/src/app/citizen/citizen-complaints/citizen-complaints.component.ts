import {
  AfterViewInit,
  Component,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { ChatWindowComponent } from 'src/app/shared/chat-window/chat-window.component';
import { ComplaintDTO } from 'src/app/shared/models/citizencomplaint';
import {
  faFaClassList,
  ListSendReminder,
} from 'src/app/shared/models/variables';
import { CitizenService } from 'src/app/shared/services/citizen.service';

@Component({
  selector: 'app-citizen-complaints',
  templateUrl: './citizen-complaints.component.html',
  styleUrls: ['./citizen-complaints.component.scss'],
})
export class CitizenComplaintsComponent
  implements OnInit, AfterViewInit, OnDestroy {
  complaints: ComplaintDTO[] = [];
  chatId!: string;
  subscriptionArray: Subscription[] = [];

  @ViewChild('chatWindow') chatWindow!: ChatWindowComponent;
  //@ts-ignore
  userId: number = sessionStorage.getItem('userId');
  imageBaseUrl: string = 'http://localhost:8080/api/download/';

  ngOnInit(): void {}

  constructor(private citizenService: CitizenService) {}

  ngAfterViewInit(): void {
    this.loadAllComplaints();
  }

  //this method will bring all the complaint of logged in citizen
  loadAllComplaints() {
    let subs = this.citizenService
      .getAllComplaintsById(this.userId)
      //@ts-ignore
      .subscribe((res: ComplaintDTO[]) => {
        this.complaints = res.map((r) => {
          r.documentPath = this.imageBaseUrl + r.documentPath;
          if (r.complaintStatus == 'RESOLVED') {
            r.remainderButton = true;
          } else {
            r.remainderButton = false;
          }
          r.statusClass = faFaClassList[r.complaintStatus];
          r.complaintStatus = ListSendReminder[r.complaintStatus];
          return r;
        });
      });
    this.subscriptionArray.push(subs);
  }

  //method will  send reminder to head if complaint is closed but work is still pending
  sendReminder(complaintId: any) {
    let subs = this.citizenService
      .sendReminder(complaintId)
      .subscribe((res) => {
        this.loadAllComplaints();
      });
    this.subscriptionArray.push(subs);
  }

  //method will open chat window to view all the conversion between citizen and head
  openChat(chatId: any) {
    this.chatId = chatId;
    this.chatWindow.openModel();
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
