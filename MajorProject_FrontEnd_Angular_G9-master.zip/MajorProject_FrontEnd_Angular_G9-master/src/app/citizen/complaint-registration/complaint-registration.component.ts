import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpEventType } from '@angular/common/http';
import { ComplaintRegisterDTO } from 'src/app/shared/models/complaintRegistration';
import { AuthService } from 'src/app/shared/services/auth-service.service';
import { CitizenService } from 'src/app/shared/services/citizen.service';
import { ValidationService } from 'src/app/shared/services/validation-service.service';
import { Department } from 'src/app/shared/models/department';
import { DepartmentService } from 'src/app/shared/services/department.service';
import { Address } from 'src/app/shared/models/address';
import { ComplaintService } from 'src/app/shared/services/complaint.service';
import { ImageResponce } from 'src/app/shared/models/image-responce';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-complaint-registration',
  templateUrl: './complaint-registration.component.html',
  styleUrls: ['./complaint-registration.component.scss'],
})
export class ComplaintRegistrationComponent implements OnInit, OnDestroy {
  //@ts-ignore
  registerForm: FormGroup;
  submitted = false;
  departments: Department[] = [];
  addresses: Address[] = [];
  imageRespones: ImageResponce = new ImageResponce();
  documentPath?: string;
  subscriptionArray: Subscription[] = [];

  //File Upload
  uploadPercentage: number = 0;
  selecetdFile!: FormData;
  showProgress: boolean = false;
  //@ts-ignore
  userId: number = sessionStorage.getItem('userId');

  constructor(
    private fb: FormBuilder,
    private customValidator: ValidationService,
    private citizenService: CitizenService,
    private departmentService: DepartmentService,
    private complaintService: ComplaintService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.departmentService
      .getAllDepartments()
      //@ts-ignore
      .subscribe((res: Department[]) => {
        this.departments = res;
      });
    //method will get all the address user has registred
    //@ts-ignore
    let subs = this.citizenService
      //@ts-ignore
      .getAllCitizenAddress(sessionStorage.getItem('userId'))
      .subscribe((res: Address[]) => {
        this.addresses = res;
      });
    this.registerForm = this.fb.group(
      {
        complaintMessage: ['', Validators.compose([Validators.required])],
        departmentId: ['', Validators.compose([Validators.required])],
        addressId: [``, Validators.compose([Validators.required])],
      },
      {
        validator: this.customValidator.MatchPassword(
          'password',
          'confirmpassword'
        ),
      }
    );
  }

  //this function will get executed once user select any file
  onFileSelected(event: any) {
    this.selecetdFile = <FormData>event.target.files[0];
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  //this function will store the image in directory(will call REST-API) method and return path
  fileUpload() {
    const fd = new FormData();
    this.submitted = true;
    if (!this.registerForm.valid) return;
    //@ts-ignore
    fd.append('file', this.selecetdFile, this.selecetdFile.name);
    let s = this;
    let subs = this.complaintService.uploadImage(fd).subscribe((events) => {
      if (events.type === HttpEventType.UploadProgress) {
        this.showProgress = true;

        this.uploadPercentage = Math.round(
          //@ts-ignore
          (events.loaded / events.total) * 100
        );
      } else if (events.type === HttpEventType.Response) {
        //@ts-ignore
        this.imageRespones = events.body;
        this.registerComplaint();
      }
    });
    this.subscriptionArray.push(subs);
  }

  registerComplaint() {
    this.submitted = true;

    if (this.registerForm.valid) {
      let complaint: any = this.registerForm.value;
      let complaintRegistrationDto = new ComplaintRegisterDTO();
      complaintRegistrationDto = {
        complaintMessage: complaint.complaintMessage,
        documentPath: this.imageRespones.fileName,
        departmentId: complaint.departmentId,
        addressId: complaint.addressId,
      };
      //register complaint method from service is called
      let subs = this.citizenService
        .registerComplaint(this.userId, complaintRegistrationDto)
        .subscribe((res) => {
          this.showProgress = false;
          this.toastr.success(
            `Complaint is registred Department head will reach you shortly`
          );
          this.router.navigate(['citizenComplaints']);
        });
      this.subscriptionArray.push(subs);
    }
  }

  //This function will call file upload and complaint registration method once user done with filing the complaint and submit it
  onSubmit() {
    if (this.selecetdFile != null) {
      this.fileUpload(); //upload file and get the path to store it in the database
    } else {
      this.registerComplaint();
    }
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
