import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { FeedbackPost } from 'src/app/shared/models/feedback-post';
import { PublicComplaint } from 'src/app/shared/models/public-complaint';
import { CitizenService } from 'src/app/shared/services/citizen.service';
import { ComplaintService } from 'src/app/shared/services/complaint.service';

@Component({
  selector: 'app-public-complaint-list',
  templateUrl: './public-complaint-list.component.html',
  styleUrls: ['./public-complaint-list.component.scss'],
})
export class PublicComplaintListComponent implements OnInit ,OnDestroy{
  constructor(
    private citizenService: CitizenService,
    private complaintService: ComplaintService,
    private router: Router
  ) {}

  complaints: PublicComplaint[] = [];
  imageBaseUrl: string = 'http://localhost:8080/api/download/';
  totalLikes: number = 0;
  totalDisLikes: number = 0;
  totalComments: number = 0;
  subscriptionArray:Subscription[]=[];

  //@ts-ignore
  userId: number = sessionStorage.getItem('userId');
  feedbackPostId?: string;
  ngOnInit(): void {
    this.getAllComplaints();
  }

  //method will get all the complaint till the current date from database
  getAllComplaints() {
    let subs= this.citizenService
      .getAllComplaint()
      .subscribe((res: PublicComplaint[]) => {
        this.complaints = res.map((r) => {
          r.documentPath = this.imageBaseUrl + r.documentPath;
          //@ts-ignore
          r.createdAt = this.calculateTimeDifference(r.createdAt);

          let subs=this.complaintService
            //@ts-ignore
            .getComplaintDetals(r.feedbackPostId)
            .subscribe((res: FeedbackPost) => {
              r.totalLike = res.likes;
              r.totalDislike = res.dislikes;
              r.totalComment = res.postComments;
            });
            this.subscriptionArray.push(subs);
          return r;
        });
      });
      this.subscriptionArray.push(subs);
  }

  //on click of like button this function will get called to store like count and get updated one
  like(feedbackPostId: any, index: number) {
    let subs=this.complaintService
      .likePost(feedbackPostId, this.userId)
      //@ts-ignore
      .subscribe((postCount: PostCounts) => {
        this.complaints[index].totalLike = postCount.totalLikes;
        this.complaints[index].totalDislike = postCount.totalDislike;
      });
      this.subscriptionArray.push(subs);
  }

  //on click of dislike button this function will get called to store dislike count and get updated one
  dislike(feedbackPostId: any, index: number) {
    let subs=this.complaintService
      .disLikePost(feedbackPostId, this.userId)
      //@ts-ignore
      .subscribe((postCount: PostCounts) => {
        this.complaints[index].totalLike = postCount.totalLikes;
        this.complaints[index].totalDislike = postCount.totalDislike;
      });
      this.subscriptionArray.push(subs);
  }

  getPublicComplaint(complaintId: any) {
    this.router.navigate(['/publicComplaint', complaintId, this.userId]);
  }

  //this function will give the time when the comment was created and the post also
  calculateTimeDifference(time: any): string {
    let commentdate = new Date(time);
    let latestTime = new Date();
    let t = 0;
    t = commentdate.getMonth() - latestTime.getMonth();
    if (t > 0) {
      return ' ' + t + ' Month Ago';
    }
    t = commentdate.getDate() - latestTime.getDate();
    if (t > 0) {
      return ' ' + t + ' Day Ago';
    }
    t = commentdate.getHours() - latestTime.getHours();
    if (t > 0) {
      return ' ' + t + ' Hour Ago';
    }
    t = commentdate.getMinutes() - latestTime.getMinutes();
    if (t > 0) {
      return ' ' + t + ' Minute Ago';
    }
    t = commentdate.getSeconds() - latestTime.getSeconds();
    if (t > 0) {
      return ' ' + t + ' Second Ago';
    }
    return ' now';
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }
}
