import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicComplaintListComponent } from './public-complaint-list.component';

describe('PublicComplaintListComponent', () => {
  let component: PublicComplaintListComponent;
  let fixture: ComponentFixture<PublicComplaintListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PublicComplaintListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicComplaintListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
