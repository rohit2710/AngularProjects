import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { CitizenRegistration } from 'src/app/shared/models/citizenRegistration';
import { AuthService } from 'src/app/shared/services/auth-service.service';
import { ValidationService } from 'src/app/shared/services/validation-service.service';

@Component({
  selector: 'app-citizen-registration',
  templateUrl: './citizen-registration.component.html',
  styleUrls: ['./citizen-registration.component.scss'],
})
export class CitizenRegistrationComponent implements OnInit, OnDestroy {
  //@ts-ignore
  registerForm: FormGroup;
  submitted = false;
  subscriptionArray: Subscription[] = [];

  constructor(
    private fb: FormBuilder,
    private customValidator: ValidationService,
    private authService: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.registerForm = this.fb.group(
      {
        fname: [
          '',
          Validators.compose([
            Validators.required,
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexNames
            ),
          ]),
        ],
        lname: [
          '',
          Validators.compose([
            Validators.required,
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexNames
            ),
          ]),
        ],
        email: [
          '',
          Validators.compose([
            Validators.required,
            Validators.email,
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexEmail
            ),
          ]),
        ],
        password: [
          '',
          Validators.compose([Validators.required, Validators.minLength(8)]),
        ],
        confirmpassword: [
          '',
          Validators.compose([
            Validators.required,
            //this.customValidator.MatchPassword.bind(this.customValidator)Validators.compose
          ]),
        ],
        mobileNo: [
          '',
          Validators.compose([
            Validators.required,
            Validators.maxLength(10),
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexMobile
            ),
          ]),
        ],
        aadharNo: [
          '',
          Validators.compose([
            Validators.required,
            Validators.maxLength(12),
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexAadhar
            ),
          ]),
        ],
        houseNo: [
          '',
          Validators.compose([
            Validators.required,
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexNoSpecialChr
            ),
          ]),
        ],
        landmark: ['', Validators.compose([Validators.required])],
        pincode: [
          '',
          Validators.compose([
            Validators.required,
            Validators.maxLength(6),
            this.customValidator.patternValidator(
              this.customValidator.regexStore.regexPincode
            ),
          ]),
        ],
        // username: ['', [Validators.required], this.customValidator.userNameValidator.bind(this.customValidator)],
      },
      {
        validator: this.customValidator.MatchPassword(
          'password',
          'confirmpassword'
        ),
      }
    );
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  //on Submmission of the form this method will be called to send the citizen detail to backend to store it in database
  onSubmit() {
    this.submitted = true;

    if (this.registerForm.valid) {
      let user: any = this.registerForm.value; //take all the values from form

      let citizenRegistration = new CitizenRegistration();

      //storing the citizen related data to object from user(Form data)
      citizenRegistration.citizenDTO = {
        aadharNo: user.aadharNo,
        email: user.email,
        mobileNo: user.mobileNo,
        name: user.fname + ' ' + user.lname,
        password: user.password,
      };

      //storing address related data to object from user(Form data)
      citizenRegistration.addressDTO = {
        houseNo: user.houseNo,
        landmark: user.landmark,
        pincode: user.pincode,
      };

      //service method call to send data to backend for processing
      let subs = this.authService
        .registerCitizen(citizenRegistration)
        .subscribe((res) => {
          this.toastr.success(
            `Congratulation Your account is created successfully`
          );
          this.router.navigate([
            '/activateAccount',
            citizenRegistration.citizenDTO?.email,
          ]);
        });
      this.subscriptionArray.push(subs);
    }
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
