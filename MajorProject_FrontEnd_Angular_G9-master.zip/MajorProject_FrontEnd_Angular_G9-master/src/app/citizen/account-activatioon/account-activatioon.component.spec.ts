import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountActivatioonComponent } from './account-activatioon.component';

describe('AccountActivatioonComponent', () => {
  let component: AccountActivatioonComponent;
  let fixture: ComponentFixture<AccountActivatioonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountActivatioonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountActivatioonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
