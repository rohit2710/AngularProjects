import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { AuthService } from 'src/app/shared/services/auth-service.service';
import { ValidationService } from 'src/app/shared/services/validation-service.service';

@Component({
  selector: 'app-account-activatioon',
  templateUrl: './account-activatioon.component.html',
  styleUrls: ['./account-activatioon.component.scss'],
})
export class AccountActivatioonComponent
  implements OnInit, AfterViewInit, OnDestroy {
  //@ts-ignore
  registerForm: FormGroup;
  submitted = false;
  status?: boolean = false;
  otp?: number;
  email?: string;
  time!: string;
  totalTime = 120;
  subscriptionArray: Subscription[] = [];

  constructor(
    private fb: FormBuilder,
    private customValidator: ValidationService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService
  ) {}

  ngAfterViewInit(): void {
    setInterval(() => {
      this.time =
        Math.floor(this.totalTime / 60) + ' M ' + (this.totalTime % 60) + ' S';
      --this.totalTime;
    }, 1000);
  }

  ngOnInit(): void {
    //@ts-ignore
    this.email = this.route.snapshot.paramMap.get('email'); //take the varible from URL

    this.registerForm = this.fb.group({
      otp: [
        '',
        Validators.compose([
          Validators.required,
          Validators.maxLength(6),
          this.customValidator.patternValidator(
            this.customValidator.regexStore.regexOTP
          ),
        ]),
      ],
    });
  }

  //method will help to get the data from the form
  get registerFormControl() {
    return this.registerForm.controls;
  }

  //on submit of form this method will be called
  onSubmit() {
    this.submitted = true;
    this.otp = this.registerForm.value.otp;
    //activate account method will take the otp and email and send it to backend for verification
    //@ts-ignore
    let subs = this.authService
      .activateAccount(this.email, this.otp)
      .subscribe((res) => {
        this.router.navigate(['/login']);
      });
    this.subscriptionArray.push(subs);
  }
  resendOTP() {
    //@ts-ignore
    let subs = this.authService.resendOTP(this.email).subscribe((res) => {
      this.toastr.success('OTP is send to your email please check.');
    });
    this.subscriptionArray.push(subs);
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
