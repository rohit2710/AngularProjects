import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CitizenRegistrationComponent } from './citizen-registration/citizen-registration.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ComplaintRegistrationComponent } from './complaint-registration/complaint-registration.component';
import { SharedModule } from '../shared/shared.module';
import { ComplaintService } from '../shared/services/complaint.service';
import { CitizenService } from '../shared/services/citizen.service';

import { CitizenComplaintsComponent } from './citizen-complaints/citizen-complaints.component';
import { PublicComplaintComponent } from './public-complaint/public-complaint.component';
import { PublicComplaintListComponent } from './public-complaint-list/public-complaint-list.component';
import { AccountActivatioonComponent } from './account-activatioon/account-activatioon.component';

@NgModule({
  declarations: [
    CitizenRegistrationComponent,
    ComplaintRegistrationComponent,
    PublicComplaintComponent,
    CitizenComplaintsComponent,
    PublicComplaintListComponent,
    AccountActivatioonComponent,
  ],
  imports: [CommonModule, ReactiveFormsModule, SharedModule],
  exports: [CitizenRegistrationComponent],
  providers: [ComplaintService, CitizenService],
})
export class CitizenModule {}
