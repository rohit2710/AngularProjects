import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { error } from 'protractor';
import { Subscription } from 'rxjs';
import { ComplaintDTO } from 'src/app/shared/models/departmentComplaints';
import { AdminService } from 'src/app/shared/services/admin.service';
import { ComplaintService } from 'src/app/shared/services/complaint.service';
import { DepartmentService } from 'src/app/shared/services/department.service';

@Component({
  selector: 'app-complaint-list',
  templateUrl: './complaint-list.component.html',
  styleUrls: ['./complaint-list.component.scss'],
})
export class ComplaintListComponent implements OnInit, OnDestroy {
  //@ts-ignore
  registerForm: FormGroup;
  complaints: any = [];
  //@ts-ignore
  employeeId: number = sessionStorage.getItem('userId');
  subscriptionArray: Subscription[] = [];

  constructor(
    private departmentService: DepartmentService,
    private router: Router,
    private complaintService: ComplaintService,
    private adminService: AdminService
  ) {}

  transferComplaint(complaintId: any) {
    this.router.navigate(['/transferComplaint', complaintId]);
  }

  updateStatus(Id: any, index: any, updatestatus: string) {
    this.complaints[index].complaintStatus = updatestatus;
    let updateStatus = new ComplaintDTO();
    updateStatus = {
      complaintStatus: updatestatus,
      complaintId: Id,
    };

    let subs = this.departmentService.statusUpdate(updateStatus).subscribe(
      (res: ComplaintDTO) => {
        console.log(res);
        this.router.navigate(['/complaints']);
      },
      (error) => {}
    );
    this.subscriptionArray.push(subs);
  }
  showMore(complaintObj: any) {
    this.complaintService.complaintSubject.next(complaintObj);
    this.router.navigate(['/complaints']);
  }
  Remark() {}

  ngOnInit(): void {
    //@ts-ignore
    this.getAllComplaintWithNoDepartment();
  }

  getAllComplaintWithNoDepartment() {
    let subs = this.adminService
      .getAllComplaintWithNoDepartment()
      .subscribe((res: ComplaintDTO[]) => {
        this.complaints = res;
      });
    this.subscriptionArray.push(subs);
  }

  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
