import { Component, OnDestroy, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { EmployeeDTO } from 'src/app/shared/models/employee';
import { AdminService } from 'src/app/shared/services/admin.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss'],
})
export class EmployeeListComponent implements OnInit, OnDestroy {
  emplist: EmployeeDTO[] = [];
  subscriptionArray: Subscription[] = [];

  constructor(private adminService: AdminService, private router: Router) {}

  //on update employee button it will navigate to update employee form
  updateEmployee(empId: any) {
    this.router.navigate(['/updateEmployee', empId]);
  }

  //on the loading of component all employees will be fetched
  ngOnInit(): void {
    let subs = this.adminService
      .getAllEmployee()
      .subscribe((res: EmployeeDTO[]) => {
        this.emplist = res;
      });
    this.subscriptionArray.push(subs);
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
