import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormGroup } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation-service.service';
import { Department } from 'src/app/shared/models/department';
import { AdminService } from 'src/app/shared/services/admin.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-department-registration',
  templateUrl: './department-registration.component.html',
  styleUrls: ['./department-registration.component.scss'],
})
export class DepartmentRegistrationComponent implements OnInit, OnDestroy {
  //@ts-ignore
  registerForm: FormGroup;
  submitted = false;
  subscriptionArray: Subscription[] = [];

  constructor(
    private fb: FormBuilder,
    private customValidator: ValidationService,
    private adminService: AdminService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  //all validations goes here
  ngOnInit(): void {
    this.registerForm = this.fb.group({
      departmentName: [
        '',
        Validators.compose([
          Validators.required,
          this.customValidator.patternValidator(
            this.customValidator.regexStore.regexFullname
          ),
        ]),
      ],
      description: [
        '',
        Validators.compose([Validators.required, Validators.maxLength(300)]),
      ],
    });
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  //on submition of form department will be registered
  onSubmit() {

    this.submitted = true;
    if(this.registerForm.valid){
      let user: any = this.registerForm.value;

      let departmentRegistration = new Department();
  
      (departmentRegistration.departmentName = user.departmentName),
        (departmentRegistration.description = user.description);
  
      let subs = this.adminService
        .registerDepartment(departmentRegistration)
        .subscribe((res) => {
          this.toastr.success(`Department created successfully`);
          this.router.navigate(['listDepartment']);
        });
      this.subscriptionArray.push(subs);
    }
   
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
