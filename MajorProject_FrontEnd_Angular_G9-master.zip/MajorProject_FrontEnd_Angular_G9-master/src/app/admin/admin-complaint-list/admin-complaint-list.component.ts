import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ComplaintDTO } from 'src/app/shared/models/departmentComplaints';
import { AdminService } from 'src/app/shared/services/admin.service';
import { ComplaintService } from 'src/app/shared/services/complaint.service';
import { DepartmentService } from 'src/app/shared/services/department.service';

@Component({
  selector: 'app-admin-complaint-list',
  templateUrl: './admin-complaint-list.component.html',
  styleUrls: ['./admin-complaint-list.component.scss'],
})
export class AdminComplaintListComponent implements OnInit ,OnDestroy{
  //@ts-ignore
  registerForm: FormGroup;
  complaints: any = [];
  subscriptionArray:Subscription[]=[];


  //@ts-ignore
  employeeId: number = sessionStorage.getItem('userId');

  constructor(
    private departmentService: DepartmentService,
    private router: Router,
    private complaintService: ComplaintService,
    private adminService: AdminService
  ) {}
  

  ngOnInit(): void {
    this.getAllComplaintWithNoDepartment();
  }

  //this function will get all the complain with no department from database
    getAllComplaintWithNoDepartment() {
   let subs =this.adminService
      .getAllComplaintWithNoDepartment()
      .subscribe((res: ComplaintDTO[]) => {
        this.complaints = res;
      });
      this.subscriptionArray.push(subs);  
  }

  //on click of transfer complaint this function will open transfer complaint component
  transferComplaint(complaintId: any) {
    this.router.navigate(['/admintransfercomplaint', complaintId]);
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }
}
