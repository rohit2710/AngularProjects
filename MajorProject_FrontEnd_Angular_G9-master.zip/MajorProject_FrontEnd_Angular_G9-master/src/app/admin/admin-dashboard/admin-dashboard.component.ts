import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { DepartmentService } from 'src/app/shared/services/department.service';
import { Department, GraphData } from 'src/app/shared/models/graphModel';
import { ComplaintService } from 'src/app/shared/services/complaint.service';
import { GraphComponent } from 'src/app/shared/graph/graph.component';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss'],
})
export class AdminDashboardComponent
  implements OnInit, AfterViewInit, OnDestroy {
  departmentArray: Department[] = [];
  graphData!: GraphData;
  totalComplaints: number = 0;
  deptId = 0;
  showGraph: boolean = false;
  subscriptionArray: Subscription[] = [];

  //this will get the child view on the dashboard of barchart and pie chart
  @ViewChild('barChart') barChart!: GraphComponent;
  @ViewChild('pieChart') pieChart!: GraphComponent;

  constructor(
    private departmentService: DepartmentService,
    private complaintService: ComplaintService
  ) {}
  ngAfterViewInit(): void {
    this.getAllDepartments();
    this.loadGraph();
  }

  //this function will get called when all the complaint and there status is fetched
  loadGraph() {
    if (
      this.barChart !== undefined &&
      this.pieChart !== undefined &&
      this.graphData !== undefined
    ) {
      this.barChart.loadChart();
      this.pieChart.loadChart();
    }
  }

  ngOnInit(): void {
    this.getAllDepartments();
    // this.loadGraph();
  }

  //to make all the department available initially this method will work in background
  getAllDepartments() {
    let subs = this.departmentService
      .getAllDepartments()
      //@ts-ignore
      .subscribe((departments: Department[]) => {
        this.departmentArray = departments;

        let subs1 = this.complaintService
          .getAllGraphData()
          .subscribe((res: GraphData) => {
            this.graphData = res;
            this.totalComplaints = this.graphData.totalComplaint;
            this.showGraph = true;
            this.loadGraph();
          });
      });
    this.subscriptionArray.push(subs);
  }

  //this method will fetch data according to the user selection if no selecton is done then al department data will be shown
  getData(departmentId: string) {
    if (departmentId == '0') {
      //@ts-ignore
      let subs = this.complaintService
        .getAllGraphData()
        .subscribe((res: GraphData) => {
          this.totalComplaints = res.totalComplaint;
          this.graphData = res;
        });
      this.subscriptionArray.push(subs);
    } else {
      let subs = this.complaintService
        //@ts-ignore
        .getAllGraphDataByDepartmentId(departmentId)
        .subscribe((res: GraphData) => {
          this.graphData = res;
          this.totalComplaints = res.totalComplaint;
        });
      this.subscriptionArray.push(subs);
    }
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach((d) => {
      d.unsubscribe();
    });
  }
}
