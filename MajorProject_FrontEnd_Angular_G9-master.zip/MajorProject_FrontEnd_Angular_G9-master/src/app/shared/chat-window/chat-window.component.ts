import { Component, ElementRef, OnInit, ViewChild, AfterViewInit, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { ChatDetails, Message, SendMessage } from '../models/chat';
import { ImageResponce } from '../models/image-responce';
import { floatClass } from '../models/variables';
import { ComplaintService } from '../services/complaint.service';
import { HttpEventType } from '@angular/common/http';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-chat-window',
  templateUrl: './chat-window.component.html',
  styleUrls: ['./chat-window.component.scss']
})
export class ChatWindowComponent implements OnInit, AfterViewInit,OnChanges,OnDestroy {


  //@ts-ignore
  @ViewChild('chatBody') chatBody: ElementRef;

  //@ts-ignore
  @ViewChild('modalbutton') modalButton: ElementRef;
  

  @Input() chatId!:string;

  senderId!: number;
  senderRole!: string;
  senderName !:string;
  messageArray: Message[] = [];
  fileBaseUrl: string = "http://localhost:8080/api/download/";
  subscriptionArray:Subscription[]=[];


  //image data
  selecetdFile!: FormData;
  showProgress: boolean = false;
  imageRespones: ImageResponce = new ImageResponce();
  uploadPercentage: number = 0;


  constructor(private complaintService: ComplaintService) { }

  ngOnChanges() {
    if(this.chatId != undefined && this.chatId!=undefined) {
      this.getAllMessages();
    }
    setTimeout(() => {
      this.chatBody.nativeElement.scrollTop =this.chatBody.nativeElement.scrollHeight;
    }, 100);
  }

  ngAfterViewInit(): void {
  
  }

  ngOnInit(): void {
    //@ts-ignore
     this.senderId = sessionStorage.getItem('userId');
     //@ts-ignore
     this.senderRole =sessionStorage.getItem('userrole');
      //@ts-ignore
      this.senderName = sessionStorage.getItem('name');
    
  }

  addMessage(textArea: HTMLTextAreaElement, documentPath?: string) {
    let sendMessage = new SendMessage();
    sendMessage.message = textArea.value;
    sendMessage.senderId = this.senderId;
    sendMessage.senderName = this.senderName;
    sendMessage.senderRole = this.senderRole;
    if (documentPath) {
      sendMessage.documentPath = documentPath;
    }
    
    let element: HTMLDivElement = this.chatBody.nativeElement;
    setTimeout(() => {
      element.scrollTop = element.scrollHeight;
    }, 100);
    this.messageArray.push({
      floatClass: floatClass['end'],
      senderId: this.senderId,
      message: textArea.value,
      senderRole: this.senderRole,
      senderName: this.senderName,
      documentPath: documentPath ? documentPath : ''
    })
    let subs = this.complaintService.sendMessage(this.chatId, sendMessage).subscribe((data: any) => {
      textArea.value = '';
    })
    this.subscriptionArray.push(subs);
  }
  
openModel(){
  let btnEle:HTMLButtonElement=this.modalButton.nativeElement;
  btnEle.click();
  this.ngOnInit();
}

  getAllMessages() {
    //@ts-ignore
    let subs = this.complaintService.getAllMessages(this.chatId).subscribe((chat: ChatDetails) => {
      this.messageArray = chat.messages;
      this.messageArray = this.messageArray.map((message) => {
        message.senderRole != this.senderRole;
        message.floatClass = message.senderRole == this.senderRole ? floatClass['end'] : floatClass['start'];
        return message;
      })
    })
    this.subscriptionArray.push(subs);
  }

  //imageupload and download

  sendMessageWithFile(textArea: HTMLTextAreaElement, inputFile: HTMLInputElement) {
    if (this.selecetdFile != null) {
      this.fileUpload(textArea, inputFile);
    }
    else {
      this.addMessage(textArea);
    }
  }


  onFileSelected(event: any) {
    this.selecetdFile = <FormData>event.target.files[0];
  }

  //file upload function for chat window
  fileUpload(textArea: HTMLTextAreaElement, inputFile: HTMLInputElement) {
    const fd = new FormData();
    //@ts-ignore
    fd.append('file', this.selecetdFile, this.selecetdFile.name);
    this.complaintService.uploadImage(fd).subscribe(events => {
      if (events.type === HttpEventType.UploadProgress) {
        this.showProgress = true;
        //@ts-ignore
        this.uploadPercentage = Math.round(events.loaded / events.total * 100);
      }
      else if (events.type === HttpEventType.Response) {
        //@ts-ignore
        this.imageRespones = events.body;
        this.addMessage(textArea, this.imageRespones.fileName);
        inputFile.value = '';
         
      }
    });
    setTimeout(() => { this.showProgress = false }, 2000)
  }
    ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }
}
