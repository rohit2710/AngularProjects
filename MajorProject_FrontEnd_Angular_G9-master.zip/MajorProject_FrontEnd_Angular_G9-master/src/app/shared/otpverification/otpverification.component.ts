import { Route } from '@angular/compiler/src/core';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../services/auth-service.service';
import { ValidationService } from '../services/validation-service.service';

@Component({
  selector: 'app-otpverification',
  templateUrl: './otpverification.component.html',
  styleUrls: ['./otpverification.component.scss'],
})
export class OTPVerificationComponent implements OnInit ,OnDestroy{
  //@ts-ignore
  registerForm: FormGroup;
  submitted = false;
  status?: boolean = false;
  otp?: number;
  email?: string;
  subscriptionArray:Subscription[]=[];

  constructor(
    private fb: FormBuilder,
    private customValidator: ValidationService,
    private authService: AuthService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    //@ts-ignore
    this.email = this.route.snapshot.paramMap.get('email');

    this.registerForm = this.fb.group({
      otp: [
        '',
        Validators.compose([
          Validators.required,
          Validators.maxLength(6),
          this.customValidator.patternValidator(
            this.customValidator.regexStore.regexOTP
          ),
        ]),
      ],
    });
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  //on submission of OTP, it will validate OTP
  onSubmit() {
    this.submitted = true;
    this.otp = this.registerForm.value.otp;
    //@ts-ignore
    let subs = this.authService.validateOtp(this.email, this.otp).subscribe((res) => {
      if (res) {
        //@ts-ignore
        this.status = res;
      }
    });
    this.subscriptionArray.push(subs);  
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }
}
