export class UpdateEmployeeDTO {
    email?: string;
    mobileNo?: string;
    
    constructor(){}
}