import { Resetpassword } from './resetpassword';

describe('Resetpassword', () => {
  it('should create an instance', () => {
    expect(new Resetpassword()).toBeTruthy();
  });
});
