export class NabarMenu{
singleMenuArray?:SingleMenu[];    
dropdownArray?:DropdownMenu[];
constructor(singleMenu?:SingleMenu[],dropdown?:DropdownMenu[]){
  this.dropdownArray = dropdown;
  this.singleMenuArray = singleMenu;
}
}

export class DropdownMenu{
dropdownTitle?:string;
SingleMenu?:SingleMenu[];
constructor(dropdownTitle?:string,singleMenu?:SingleMenu[]){
    this.dropdownTitle = dropdownTitle;
    this.SingleMenu = singleMenu;
}
}

export class SingleMenu{
title?:string;
routerLink?:string;
constructor(title?:string,routerLink?:string){
    this.routerLink = routerLink;
    this.title = title;
}
}

export enum UserRole{
  DEPARTMENTHEAD='DEPARTMENTHEAD',CITIZEN='CITIZEN',ADMIN='ADMIN'
}