export class Resetpassword {
    userId?:number;
    password?:string;
    constructor(){}
}
