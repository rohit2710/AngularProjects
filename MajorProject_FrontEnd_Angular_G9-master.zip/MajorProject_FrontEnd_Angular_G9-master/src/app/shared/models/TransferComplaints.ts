export class TransferComplaints{
    complaintId?:number;
    departmentId?:number

    constructor(){}
}