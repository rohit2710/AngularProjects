export class EmployeeDTO {
    employeeId?: number;
    name?: string;
    email?: string;
    role?: string;
    mobileNo?: string;
    departmentName?: string;

    constructor(){}
}