


export interface Message {
    documentPath: string;
    message: string;
    senderId: number;
    senderName: string;
    senderRole: string;
    timestamp?: any;
    floatClass: string;
}

export interface ChatDetails {
    citizenId: number;
    departmentId: number;
    id: string;
    messages: Message[];
}




export class SendMessage {
    documentPath?: string;
    message?: string;
    senderId?: number;
    senderName?: string;
    senderRole?: string;
    constructor(){

    }

}



