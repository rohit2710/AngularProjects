import { FeedbackPost } from './feedback-post';

describe('FeedbackPost', () => {
  it('should create an instance', () => {
    expect(new FeedbackPost()).toBeTruthy();
  });
});
