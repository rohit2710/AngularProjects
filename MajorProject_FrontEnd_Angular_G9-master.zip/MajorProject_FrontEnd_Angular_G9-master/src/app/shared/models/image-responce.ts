export class ImageResponce {
    fileName?: string;
    fileDownloadUri?: string;
    fileType?: string;
    size?: number;
    constructor(){
        
    }
}
