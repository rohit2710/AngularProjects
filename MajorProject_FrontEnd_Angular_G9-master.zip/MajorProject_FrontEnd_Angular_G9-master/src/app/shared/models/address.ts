export class Address {
    addressId?:number;
    houseNo?:string;
    landmark?:string;
    pincode?:string;

    constructor(){}
    
}
