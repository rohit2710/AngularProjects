export interface ComplaintDTO{
    complaintId?:number;
    complaintMessage?: string;
    createdAt?:Date;
    resolvedAt?:Date;
    complaintStatus?: any;
    documentPath?: string;
    reminder?:boolean;
    departmentId?: number;
    addressId?: number;
    citizenDTO?:CitizenDTO;
    departmentName?:string;
    addressDTO?: AddressDTO;
    statusClass?:string;
    remainderButton:boolean;
    address?:AddressDTO;
    chatId?: string;
    feedbackPostId?: string;

}

export class CitizenDTO{
    name?: string;
	email?: string; 
	mobileNo?:string;
    aadharNo?:string;
    
    constructor(){}
}

export class AddressDTO{
    houseNo?: string;
	landmark?: string;
    pincode?: string;
    
    constructor(){}

}
