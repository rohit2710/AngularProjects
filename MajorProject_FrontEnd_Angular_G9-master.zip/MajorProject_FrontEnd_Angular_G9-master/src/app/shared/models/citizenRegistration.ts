
export class CitizenRegistration{
    citizenDTO?:citizenDTO;
    addressDTO?:addressDTO;

    constructor(){}
}
    export class citizenDTO {
      
        name?: string;
        email?: string;
        password?: string;
        mobileNo?: string;
        aadharNo?: string;
        constructor(){}
    }

    export class addressDTO {
        houseNo?: string;
        landmark?: string;
        pincode?: string;
        constructor(){}
    }

