export interface Department {
    departmentId: number;
    departmentName: string;
    description: string;
}
export interface StatusData {
    count: number;
    status: string;
}

export interface GraphData {
    totalComplaint: number;
    statusData: StatusData[];
}