export class PublicComplaint {
        complaintId?: number;
        complaintMessage?: string;
        createdAt?: Date;
        documentPath?: string;
        feedbackPostId?: string;
        citizenName?: string;
        departmentName?: string;
        totalLike?:number;
        totalDislike?:number;
        totalComment?:number
        constructor(){}
}
