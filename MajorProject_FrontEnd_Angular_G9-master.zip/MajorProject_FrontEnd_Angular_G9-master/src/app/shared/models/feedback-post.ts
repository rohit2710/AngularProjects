export class FeedbackPost {
     likes?:number;
	 dislikes?:number;
	 postComments?:number;
     ratings?:number;
     constructor(){}
}
