import { LockedUser } from './locked-user';

describe('LockedUser', () => {
  it('should create an instance', () => {
    expect(new LockedUser()).toBeTruthy();
  });
});
