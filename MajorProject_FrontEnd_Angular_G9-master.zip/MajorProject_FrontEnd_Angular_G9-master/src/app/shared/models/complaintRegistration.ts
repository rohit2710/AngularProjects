
export class ComplaintRegisterDTO{
    complaintMessage?: string;
    documentPath?: string;
    departmentId?: number;
    addressId?: number;

    constructor(){}
}