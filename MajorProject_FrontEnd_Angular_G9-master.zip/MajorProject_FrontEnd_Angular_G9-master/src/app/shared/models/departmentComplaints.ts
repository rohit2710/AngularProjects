export class ComplaintDTO {
    complaintId?: number;
    complaintMessage?: string;
    createdAt?: string;
    complaintStatus?: any;
    documentPath?: string;
    showCitizen?: ShowCitizen;
    address?: Address;
    chatId?:string;
    constructor(){}
  }
  
  export class Address {
    houseNo?: string;
    landmark?: string;
    pincode?: string;
    constructor(){}
  }
  
  export class ShowCitizen {
    name?: any;
    email?: any;
    mobileNo?: any;
    aadharNo?: any;
    
    constructor(){}
  }