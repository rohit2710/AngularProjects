
export class EmployeeRegistrationDTO {
    name?: string;
    email?: string;
    password?: string;
    role?: string;
    mobileNo?: string;
    departmentId?: number;
    constructor(){}
}