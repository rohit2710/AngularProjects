export var faFaClassList:{[key: string]: string} =
    {"REOPENED" :"fa fa-spinner",
     "RESOLVED" :"fa fa-check",
     "PENDING" :"fa fa-clock-o"   
      }

export var ListSendReminder:{[key: string]: string} =
      {"REOPENED" :"REOPENED",
       "RESOLVED" :"RESOLVED",
       "PENDING" :"PENDING"   
      }

      export var floatClass:{[key: string]: string} =
    {start :"float-start",
     end :"float-end",
      }

  