export class LockedUser {
        userId?: any;
        name?: string;
        email?: string;
        role?: string;

        constructor(){}
}
