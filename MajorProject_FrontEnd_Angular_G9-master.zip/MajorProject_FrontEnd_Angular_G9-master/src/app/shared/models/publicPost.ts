export interface ComplaintPP {
    complaintId: number;
    complaintMessage: string;
    createdAt: Date;
    updatedAt?: any;
    resolvedAt?: any;
    complaintStatus?: any;
    documentPath: string;
    reminder: boolean;
    feedbackPostId: string;
    chatId: string;
}
export interface CitizenPP {
    citizenId: number;
    name: string;
    email: string;
    password: string;
    role: string;
    mobileNo: string;
    aadharNo: string;
    loginAttempts?: any;
    createdAt: Date;
    lastLogin?: any;
    actived: boolean;
}

export interface PostComment {
    userId: number;
    userName: string;
    message: string;
    commentTime?: Date;
    elaspedTime?:String;
}

export interface PostFeedback {
    likes: number[];
    dislikes: number[];
    postComments: PostComment[];
    ratings?: any;
}

export interface PostCounts {
    totalLikes: number;
    totalDislike: number;
    totalComments: number;
    averageRating: number;
    totalRating: number;
}

export class CommentMessage {
    message?: string;
    userId?: number;
    userName?: string;
    constructor(){

    }
}