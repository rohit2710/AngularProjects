import { Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import * as Chart from 'chart.js';
import { GraphData } from '../models/graphModel';

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.scss']
})
export class GraphComponent implements OnInit,OnChanges {
  @ViewChild('myChart') chartRef!: ElementRef;
  chartElementRef!: HTMLCanvasElement;
  myChart!: Chart;
  lable:string[]=[""];
  data:number[] = [0];
  @Input() charType: string = "bar";
  @Input() chartData!:GraphData;


  constructor() { }
  


  ngAfterViewInit(): void {
    this.chartElementRef = this.chartRef.nativeElement;
  }

  ngOnChanges(changes: SimpleChanges) {
    this.loadChart();
  }

  //this function will load chart
  loadChart() {
    if(this.chartData !== undefined && this.chartData.statusData != undefined){
      if(this.myChart !== undefined){
        //@ts-ignore
        this.myChart =  this.myChart.destroy() ;
        }    
      this.lable=[];
    this.data=[];
    this.chartData.statusData.forEach(graphdata => {
      this.data.push(graphdata.count);
      this.lable.push(graphdata.status);
      this.chart();
    })
  
  }
  }

  ngOnInit(): void {
    this.loadChart();
  }

  chart() {
    if(this.chartRef !== undefined){
   
    this.myChart = new Chart(this.chartRef.nativeElement, {
      type: this.charType,
      data: {
        labels: this.lable,
        datasets: [{
          label: 'Complaint '+this.charType+ " chart",
          data: this.data,
          backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
          ],
          borderWidth: 1
        }]
      },
      options: {

        tooltips: {
          //enabled:false,
        },
        animation: {
          easing: 'easeInOutBack',
          duration: 2000
        },
        scales: {
          yAxes: [{
            display: true,
            gridLines: {
              drawOnChartArea: false
            },
            ticks: {
              beginAtZero: true,
              stepSize: 1
      
            }
          }]
        }
      }
    });
    this.myChart.update();
  }
}
}
