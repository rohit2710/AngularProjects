import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Resetpassword } from '../models/resetpassword';
import { AuthService } from '../services/auth-service.service';
import { ValidationService } from '../services/validation-service.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit ,OnDestroy{
 //@ts-ignore
 registerForm: FormGroup;
 submitted = false;
 subscriptionArray:Subscription[]=[];

  changePassword = new Resetpassword();
 constructor(private fb: FormBuilder,
   private customValidator: ValidationService, 
   private authService:AuthService,
   private router: Router) { }

   //validations
 ngOnInit(): void {
   this.registerForm = this.fb.group({
     otpverify: ['', Validators.compose([Validators.required, Validators.maxLength(6), this.customValidator.patternValidator(this.customValidator.regexStore.regexOTP)])],
     password: ['', Validators.compose([Validators.required])],
     confirmpassword: ['', Validators.compose([Validators.required])],
   },
   {
     validator: this.customValidator.MatchPassword('password', 'confirmpassword'),
   }
   );
 }

 get registerFormControl() {
   return this.registerForm.controls;
 }

 //on submission of form password will reset and navigate to login page 
 onSubmit() {
   this.submitted = true;
   this.changePassword.password = this.registerForm.value.password;
   //@ts-ignore
   this.changePassword.userId=sessionStorage.getItem('userId');
   let subs =this.authService.resetPassword(this.changePassword).subscribe(res => {
     this.authService.logout()
     this.authService.navbarMenuSubject.next(this.authService.navBars.commonMenu)
     this.authService.nameSubject.next('')
     this.router.navigate(['/login'])
   })
   this.subscriptionArray.push(subs);
 }
 ngOnDestroy(): void {
  this.subscriptionArray.forEach(d => {
    d.unsubscribe();
  })
}
}
