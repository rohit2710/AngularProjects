import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit,OnChanges {

//@ts-ignore
  totalPageCount:number=1;
  @Input() totalItems:number=1;
  @Input() itemsPerPage:number=1;

  @Output() pageDataRequest: EventEmitter<any> = new EventEmitter();

  paginationArray:number[]=[];
  currentPage:number=0;

  constructor() { }
  ngOnChanges(changes: SimpleChanges): void {
    this.loadPaginater();
  }

  loadPaginater(){
    this.totalPageCount=Math.ceil(this.totalItems/this.itemsPerPage);
    this.paginationArray=[];

    for (let index = 1 ; index <= this.totalPageCount; index++) {
      this.paginationArray.push(index)
    }

  }

  ngOnInit(): void {

  }
  pageNumber(pageNum:number){
      this.currentPage = pageNum;
      this.pageDataRequest.emit(pageNum);
      
  }

}
