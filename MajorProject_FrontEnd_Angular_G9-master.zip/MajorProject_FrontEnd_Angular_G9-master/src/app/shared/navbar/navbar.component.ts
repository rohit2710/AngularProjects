import { AfterViewInit, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { NabarMenu } from '../models/navbarMenu';
import { AuthService } from '../services/auth-service.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit ,OnDestroy{
  navMenuArry: NabarMenu = {};
  isUserLoggedIn: boolean=false;
  userName:string;
  subscriptionArray:Subscription[]=[];

  constructor(private authService: AuthService,private router: Router, private toastr: ToastrService) { }

  //on loading of user particular navbar will be loaded
  ngOnInit(): void {
    let subs1 =this.authService.navbarMenuSubject.subscribe((nav => {
      this.navMenuArry = nav;
    }))
    this.subscriptionArray.push(subs1);  
    let subs2 =this.authService.loginStatus.subscribe(status => {
      this.isUserLoggedIn = status;
    })
    this.subscriptionArray.push(subs2);  
    let subs3 =this.authService.nameSubject.subscribe(name => {
       this.userName=name;
    })
    this.subscriptionArray.push(subs3);  
  }

  //on logout button session will be destroyed and navigate to login page
  logout(){ 
    this.toastr.success(`${sessionStorage.getItem('name')} your logged-out`);
    this.authService.logout();
    this.router.navigate(['login'])
    this.authService.changeNav();
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }

}
