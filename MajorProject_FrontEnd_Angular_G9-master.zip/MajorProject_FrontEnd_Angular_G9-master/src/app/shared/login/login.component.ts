import { Component, OnDestroy, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from 'src/app/shared/services/validation-service.service';
import { AuthService } from '../services/auth-service.service';
import { UserRole } from '../../shared/models/navbarMenu'
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit ,OnDestroy{
  userrole?:string;
  loginForm!: FormGroup;
  submitted = false;
  username?:string;
  password?:string;
  subscriptionArray:Subscription[]=[];

  constructor(private fb: FormBuilder,
    private customValidator: ValidationService,
    private authService: AuthService,
    private router:Router,
    private toastr: ToastrService) { }

  ngOnInit(): void {

    this.loginForm = this.fb.group({
      username: [
        '',
        Validators.compose([
          Validators.required,
          Validators.email,
          this.customValidator.patternValidator(
            this.customValidator.regexStore.regexEmail
          ),
        ]),
      ],
      password: ['', Validators.compose([Validators.required,
        // this.customValidator.patternValidator("")
      ])
      ],

    },
      {
        validator: this.customValidator.MatchPassword('password', 'confirmpassword'),
      }
    );
  }

  get registerFormControl() {
    return this.loginForm.controls;
  }

  //on submission it will check for correct credentials if credentials are correct it will be logged in 
  onSubmit() {
    this.submitted = true;
    console.table(this.loginForm.value);
    this.username = this.loginForm.value.username;
    this.password = this.loginForm.value.password;
    console.log(this.username +""+ this.password);
    
   //@ts-ignore
   let subs =this.authService.authenticate(this.username, this.password)
    .subscribe(
      data => {
        this.toastr.success(`Welcome ${sessionStorage.getItem('name')}`)
        //@ts-ignore
       this.authService.changeNav();
      },
      error =>{
        this.toastr.error(`login failure`)
        //stay on same page
        console.log("login fail");
      }
    )
    this.subscriptionArray.push(subs);  
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }
}
