import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../services/auth-service.service';
import { ValidationService } from '../services/validation-service.service';

@Component({
  selector: 'app-otpgeneration',
  templateUrl: './otpgeneration.component.html',
  styleUrls: ['./otpgeneration.component.scss']
})
export class OTPGenerationComponent implements OnInit ,OnDestroy{

   //@ts-ignore
   registerForm: FormGroup;
   submitted = false;
   email?:string;
   subscriptionArray:Subscription[]=[];

   constructor(private fb: FormBuilder,
    private customValidator: ValidationService,
    private authService:AuthService,
    private router: Router) { }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      email: ['', Validators.compose([Validators.required, Validators.email,this.customValidator.patternValidator(this.customValidator.regexStore.regexEmail)])]
      
    }
    );
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  //on submission OTP will be generated for that email address
  onSubmit() {
 this.submitted = true;
 
 this.email = this.registerForm.value.email;
 //@ts-ignore
    let subs=this.authService.validateEmail(this.email).subscribe((res:boolean) =>{
      if(res){
        this.router.navigate(['/otpverification',this.email])
      }
    })
    this.subscriptionArray.push(subs);  
  }
  ngOnDestroy(): void {
    this.subscriptionArray.forEach(d => {
      d.unsubscribe();
    })
  }
}
