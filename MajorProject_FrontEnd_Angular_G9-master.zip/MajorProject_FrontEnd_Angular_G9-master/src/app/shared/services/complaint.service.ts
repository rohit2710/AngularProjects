import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { SendMessage } from '../models/chat';
import { GraphData } from '../models/graphModel';
import { CommentMessage } from '../models/publicPost';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {

  constructor(private http:HttpClient) { }
  // POST /api/uploadFile
  
 complaintSubject = new BehaviorSubject(null);


  uploadImage(image:any){
   return this.http.post(environment.baseUrl+"/api/upload",image,{
     reportProgress:true,
     observe:'events'
   });   
  }

  downloadFile(documentPath:string){
    return this.http.get(environment.baseUrl+'/api/download/'+documentPath,{responseType: 'blob'})
  }

  getCitizenById(){
    return this.http.get(`${environment.baseUrl}/app/test/getCitizenById/1`);
  } 

  getComplaintsById(complaintId:any){
    return this.http.get(`${environment.baseUrl}/app/test/getComplaintById/${complaintId}`);
  }

  getComplaintDetals(feedbackPostId:string){
    return this.http.get(`${environment.baseUrl}/app/test/loadpost/${feedbackPostId}`);
  }

  //Like Dislike Commets
  likePost(feedbackPostId:string,userId:number){
    return this.http.post(environment.baseUrl+'/app/test/like/'+feedbackPostId+'/'+userId,null);
  }

  disLikePost(feedbackPostId:string,userId:number){
    return this.http.post(environment.baseUrl+'/app/test/dislike/'+feedbackPostId+'/'+userId,null);
  }

  addComment(feedbackPostId:string,commetMessage:CommentMessage){
   return this.http.post(environment.baseUrl+'/app/test/addCommets/'+feedbackPostId,commetMessage);
  }

  ///chatting
  getAllMessages(chatId:string){
    return this.http.get(environment.baseUrl+'/app/test/getchat/'+chatId);
  }
  sendMessage(chatId:string,message:SendMessage){
    return this.http.post(environment.baseUrl+'/app/test/addmessage/'+chatId,message);
  }
  
  getComplaintDetal(feedbackPostId:string){
    return this.http.get(`${environment.baseUrl}/app/test/post/${feedbackPostId}`);
  }
  
  getAllGraphData(){
   return this.http.get(`${environment.baseUrl}/api/admin/getAllGraphData`);
  }

  getAllGraphDataByDepartmentId(departmentId:string){
    return this.http.get(`${environment.baseUrl}/api/admin/getGraphDataByDepartment/${departmentId}`);
   }

  getDataByDepartmentId(departmentId:string){
    return this.http.get(`${environment.baseUrl}/api/department/getDataByDeptId/${departmentId}`);
   }
}
